#include "VersusLayer.hpp"
#include "Profile.hpp"
#include "RankSystem.hpp"
#include <Geode/ui/GeodeUI.hpp>
#include <Geode/utils/general.hpp>
#include <Geode/binding/GJDifficultySprite.hpp>
#include <algorithm>
#include <array>
#include <chrono>

using namespace geode::prelude;
using namespace geode::utils;

namespace {
std::array<int, 3> parseVersion3(std::string value) {
    if (!value.empty() && (value[0] == 'v' || value[0] == 'V')) value.erase(value.begin());
    std::array<int, 3> out{0, 0, 0};
    size_t start = 0;
    for (int i = 0; i < 3; ++i) {
        auto end = value.find('.', start);
        auto part = value.substr(start, end == std::string::npos ? std::string::npos : end - start);
        out[i] = geode::utils::numFromString<int>(part).unwrapOr(0);
        if (end == std::string::npos) break;
        start = end + 1;
    }
    return out;
}

bool newerThanCurrent(std::string const& latest) {
    constexpr auto current = "v0.1.0";
    return parseVersion3(latest) > parseVersion3(current);
}
}

VersusLayer* VersusLayer::create() {
    auto ret = new VersusLayer();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

CCScene* VersusLayer::scene() {
    auto scene = CCScene::create();
    scene->addChild(VersusLayer::create());
    return scene;
}

bool VersusLayer::init() {
    if (!CCLayer::init()) return false;

    auto win = CCDirector::sharedDirector()->getWinSize();

    auto bg = CCSprite::create("GJ_gradientBG.png");
    if (bg) {
        bg->setAnchorPoint({0, 0});
        bg->setPosition({0, 0});
        bg->setScaleX(win.width / bg->getContentSize().width);
        bg->setScaleY(win.height / bg->getContentSize().height);
        bg->setColor({25, 40, 80});
        addChild(bg, -10);
    }

    auto title = CCLabelBMFont::create("VERSUS", "bigFont.fnt");
    title->setPosition({win.width / 2.f, win.height - 34.f});
    title->setScale(.8f);
    addChild(title);

    m_rankLabel = CCLabelBMFont::create("UNRANKED", "bigFont.fnt");
    m_rankLabel->setScale(.62f);
    m_rankLabel->setPosition({win.width / 2.f, win.height - 92.f});
    addChild(m_rankLabel);

    m_tierLabel = CCLabelBMFont::create("PLACEMENT", "goldFont.fnt");
    m_tierLabel->setScale(.45f);
    m_tierLabel->setPosition({win.width / 2.f, win.height - 118.f});
    addChild(m_tierLabel);

    m_statusLabel = CCLabelBMFont::create("", "chatFont.fnt");
    m_statusLabel->setScale(.55f);
    m_statusLabel->setPosition({win.width / 2.f, 57.f});
    addChild(m_statusLabel);

    m_actionMenu = CCMenu::create();
    m_actionMenu->setPosition({0, 0});
    addChild(m_actionMenu, 5);

    auto findBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("FIND MATCH", 150, true, "bigFont.fnt", "GJ_button_01.png", 30.f, .7f),
        this,
        menu_selector(VersusLayer::onFindMatch)
    );
    findBtn->setPosition({win.width / 2.f, win.height / 2.f + 10.f});
    m_actionMenu->addChild(findBtn);

    auto jukeboxBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("JUKEBOX", 110, true, "bigFont.fnt", "GJ_button_02.png", 30.f, .62f),
        this,
        menu_selector(VersusLayer::onJukebox)
    );
    jukeboxBtn->setPosition({win.width / 2.f - 85.f, win.height / 2.f - 52.f});
    m_actionMenu->addChild(jukeboxBtn);

    auto demoBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("TEST ROUND", 120, true, "bigFont.fnt", "GJ_button_04.png", 30.f, .55f),
        this,
        menu_selector(VersusLayer::onDemoPlacement)
    );
    demoBtn->setPosition({win.width / 2.f + 85.f, win.height / 2.f - 52.f});
    m_actionMenu->addChild(demoBtn);

    m_updateButton = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("UPDATE", 95, true, "bigFont.fnt", "GJ_button_05.png", 30.f, .55f),
        this,
        menu_selector(VersusLayer::onUpdate)
    );
    m_updateButton->setPosition({win.width - 72.f, 55.f});
    m_updateButton->setVisible(false);
    m_actionMenu->addChild(m_updateButton);

    m_restartButton = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("RESTART", 95, true, "bigFont.fnt", "GJ_button_05.png", 30.f, .52f),
        this,
        menu_selector(VersusLayer::onRestart)
    );
    m_restartButton->setPosition({win.width - 72.f, 29.f});
    m_restartButton->setVisible(false);
    m_actionMenu->addChild(m_restartButton);

    auto backBtn = CCMenuItemSpriteExtra::create(
        CCSprite::createWithSpriteFrameName("GJ_arrow_01_001.png"),
        this,
        menu_selector(VersusLayer::onBack)
    );
    backBtn->setPosition({25.f, win.height - 25.f});
    m_actionMenu->addChild(backBtn);

    refreshProfile();
    checkInternet();
    checkBackendVersion();
    setKeypadEnabled(true);
    return true;
}

void VersusLayer::refreshProfile() {
    auto& profile = versus::Profile::get();
    if (!profile.placed()) {
        m_rankLabel->setString(fmt::format("PLACEMENT {}/10", profile.placementCount()).c_str());
        m_tierLabel->setString("ANALYZING SKILL");
    } else {
        auto info = versus::RankSystem::infoFor(profile.rating());
        m_rankLabel->setString(info.displayRating.c_str());
        m_tierLabel->setString(info.label.c_str());
    }
    rebuildRankFace();
}

void VersusLayer::rebuildRankFace() {
    if (m_rankFace) {
        m_rankFace->removeFromParent();
        m_rankFace = nullptr;
    }

    auto& profile = versus::Profile::get();
    auto info = versus::RankSystem::infoFor(profile.rating());
    auto face = GJDifficultySprite::create(
        versus::RankSystem::gdDifficultyIcon(info.tier),
        GJDifficultyName::Short
    );
    if (!face) return;

    auto win = CCDirector::sharedDirector()->getWinSize();
    face->setPosition({win.width / 2.f, win.height - 158.f});
    face->setScale(.85f);
    addChild(face, 2);
    m_rankFace = face;
}

void VersusLayer::showOfflineMessage() {
    FLAlertLayer::create(
        "Versus",
        "I can't connect to the internet. Please double-check your internet access.",
        "OK"
    )->show();
}

void VersusLayer::checkInternet() {
    auto url = Mod::get()->getSettingValue<std::string>("internet-check-url");
    if (url.empty()) return;

    web::WebRequest req;
    req.timeout(std::chrono::seconds(6));
    m_internetTask.spawn(req.get(url, Mod::get()), [this](web::WebResponse response) {
        if (!response.ok()) {
            showOfflineMessage();
            m_statusLabel->setString("OFFLINE");
        } else {
            m_statusLabel->setString("ONLINE");
        }
    });
}

void VersusLayer::checkBackendVersion() {
    auto base = Mod::get()->getSettingValue<std::string>("server-url");
    if (base.empty()) return;
    while (!base.empty() && base.back() == '/') base.pop_back();

    web::WebRequest req;
    req.timeout(std::chrono::seconds(6));
    m_versionTask.spawn(req.get(base + "/v1/version", Mod::get()), [this](web::WebResponse response) {
        if (!response.ok()) return;
        auto json = response.json();
        if (json.isErr()) return;
        auto latest = json.unwrap().get<std::string>("latestVersion");
        if (latest.isErr()) return;

        if (newerThanCurrent(latest.unwrap())) {
            m_updateAvailable = true;
            m_updateButton->setVisible(true);
            m_statusLabel->setString("UPDATE AVAILABLE");
        }
    });
}

void VersusLayer::showRouletteResult() {
    auto& profile = versus::Profile::get();
    auto difficulty = versus::RankSystem::rouletteDifficulty(profile.rating());
    auto name = versus::RankSystem::difficultyName(difficulty);
    FLAlertLayer::create(
        "LEVEL ROULETTE",
        fmt::format("Selected difficulty: <cg>{}</c>\n\nAuto and None levels are excluded.", name),
        "OK"
    )->show();
}

void VersusLayer::onBack(CCObject*) {
    CCDirector::sharedDirector()->popScene();
}

void VersusLayer::onFindMatch(CCObject*) {
    auto base = Mod::get()->getSettingValue<std::string>("server-url");
    if (base.empty()) {
        showRouletteResult();
        FLAlertLayer::create(
            "Versus Prototype",
            "The local rank-aware roulette is active. Online matchmaking will activate when a Versus server URL is configured.",
            "OK"
        )->show();
        return;
    }

    while (!base.empty() && base.back() == '/') base.pop_back();
    auto& profile = versus::Profile::get();
    matjson::Value body;
    body["rating"] = profile.rating();
    body["placed"] = profile.placed();

    web::WebRequest req;
    req.timeout(std::chrono::seconds(8));
    req.bodyJSON(body);
    m_statusLabel->setString("FINDING MATCH...");
    m_matchTask.spawn(req.post(base + "/v1/match/join", Mod::get()), [this](web::WebResponse response) {
        if (!response.ok()) {
            showOfflineMessage();
            m_statusLabel->setString("MATCHMAKING FAILED");
            return;
        }
        auto json = response.json();
        if (json.isErr()) return;
        auto difficulty = json.unwrap().get<std::string>("difficulty").unwrapOr("Hard");
        auto ticket = json.unwrap().get<std::string>("ticket").unwrapOr("queued");
        m_statusLabel->setString("MATCH TICKET CREATED");
        FLAlertLayer::create(
            "Versus",
            fmt::format("Matchmaking ticket: <cg>{}</c>\nRoulette target: <cy>{}</c>", ticket, difficulty),
            "OK"
        )->show();
    });
}

void VersusLayer::onJukebox(CCObject*) {
    geode::openInfoPopup("fleym.nongd");
    FLAlertLayer::create(
        "Jukebox",
        "Jukebox is installed as a required Versus dependency. Open a level and tap its song name to use Jukebox song management.",
        "OK"
    )->show();
}

void VersusLayer::onUpdate(CCObject*) {
    if (!m_updateAvailable) return;
    geode::openInfoPopup("k2qr.versus");
    m_restartButton->setVisible(true);
    FLAlertLayer::create(
        "Update",
        "Install the available Versus update in Geode. When installation finishes, press Restart to apply the new version.",
        "OK"
    )->show();
}

void VersusLayer::onRestart(CCObject*) {
    versus::Profile::get().save();
    geode::utils::game::restart(true);
}

void VersusLayer::onDemoPlacement(CCObject*) {
    auto& profile = versus::Profile::get();
    auto difficulty = versus::RankSystem::rouletteDifficulty(profile.rating());

    versus::MatchRecord record;
    record.won = true;
    record.completed = true;
    record.progress = 100.f;
    record.deaths = 2;
    record.opponentRating = std::max(1000, profile.rating() + 30);
    record.difficulty = difficulty;

    profile.applyRankedResult(record);
    refreshProfile();

    if (profile.placed()) {
        auto info = versus::RankSystem::infoFor(profile.rating());
        FLAlertLayer::create(
            "Saved",
            fmt::format("Autosaved. Current rank: <cg>{}</c> ({})", info.displayRating, info.label),
            "OK"
        )->show();
    } else {
        FLAlertLayer::create(
            "Placement Saved",
            fmt::format("Placement progress: <cg>{}/10</c>", profile.placementCount()),
            "OK"
        )->show();
    }
}

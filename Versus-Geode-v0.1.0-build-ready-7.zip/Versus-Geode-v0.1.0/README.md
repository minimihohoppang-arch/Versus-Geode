# Versus for Geode

Versus v0.2.0 adds ranked one-run battles for Geometry Dash.

- If a Versus backend URL is configured, FIND MATCH waits for a human opponent.
- If no human is found within the backend timeout, a rank-matched bot automatically joins.
- If no backend is configured or the backend is unreachable, local bot matchmaking still works.
- Both human players receive the same roulette difficulty and level ID.
- Auto and N/A levels are not used.
- The first death or a full clear ends the one-run battle and saves the result.

The included `server/` folder is the reference matchmaking backend. It must be hosted and its HTTPS URL entered in the `Versus Server URL` setting for real player-vs-player matchmaking. Bot matches work without a hosted backend.

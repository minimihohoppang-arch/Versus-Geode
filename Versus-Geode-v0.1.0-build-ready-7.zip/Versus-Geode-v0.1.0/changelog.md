# Changelog

## v0.2.0
- Added real human matchmaking protocol through the Versus backend.
- Added automatic bot fallback when no human is found or the server is unavailable.
- Added rank-aware level roulette with Auto/None excluded.
- Added PLAY MATCH flow that opens the exact selected level ID.
- Added one-run gameplay tracking through PlayLayer.
- Added bot result comparison and automatic rank/placement updates.
- Added human result submission and pending-result collection.

## v0.1.0
- Initial prototype.

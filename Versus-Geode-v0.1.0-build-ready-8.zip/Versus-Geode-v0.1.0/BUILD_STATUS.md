# Build status

Versus v0.2.0 source package.

Implemented:
- Human matchmaking client/server protocol.
- Automatic bot fallback after 8 seconds when no player is found.
- Local bot fallback when the backend is not configured or unreachable.
- Rank-aware level roulette with Auto/N/A excluded.
- Same selected level ID for both human players.
- One-run PlayLayer result tracking.
- Bot result comparison and rank/placement autosave.
- Human result submission and pending-result collection.
- Jukebox dependency integration.

Important: real player-vs-player matchmaking requires hosting the included `server/` backend and entering its HTTPS URL in the Versus Server URL setting. Bot matchmaking works without a server.

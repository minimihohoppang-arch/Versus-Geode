## v0.3.0
- Added Google Drive update checks through a configurable Google Apps Script web app.
- Added automatic Update Available popup when entering Versus.
- Added direct .geode download, SHA-256 verification, package ID/version validation, safe replacement, and restart prompt.
- Human matchmaking and bot fallback from v0.2.0 remain enabled.

# Changelog

## v0.2.0
- Added real human matchmaking protocol through the Versus backend.
- Added automatic bot fallback when no human is found or the server is unavailable.
- Added rank-aware level roulette with Auto/None excluded.
- Added PLAY MATCH flow that opens the exact selected level ID.
- Added one-run gameplay tracking through PlayLayer.
- Added bot result comparison and automatic rank/placement updates.
- Added human result submission and pending-result collection.

## v0.1.0
- Initial prototype.

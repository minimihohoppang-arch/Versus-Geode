# Versus Google Drive updater setup

This folder contains the Google Apps Script endpoint used by Versus v0.3.0+.

## 1. Create a Google Drive folder

Create a folder named `Versus Updates` and set it so anyone with the link can view files in the folder.

Copy the folder ID from the Drive URL and paste it into `Code.gs`:

```js
const VERSUS_FOLDER_ID = 'YOUR_FOLDER_ID';
```

## 2. Create the Apps Script web app

1. Open Google Apps Script and create a new project.
2. Replace the default code with `Code.gs`.
3. Deploy -> New deployment -> Web app.
4. Execute as: Me.
5. Who has access: Anyone.
6. Deploy and copy the `/exec` URL.

## 3. Configure Versus

Open Geode -> Versus settings and paste the `/exec` URL into:

`Google Drive Update API URL`

Keep `Check Updates on Versus Open` enabled.

## 4. Publish an update

Upload the compiled file using this exact naming pattern:

`k2qr.versus-vMAJOR.MINOR.PATCH.geode`

Example:

`k2qr.versus-v0.3.1.geode`

When a player opens the Versus screen, the mod asks the Apps Script endpoint for the highest version. If it is newer than the installed version, an Update Available popup appears.

The client downloads the new package, verifies SHA-256, verifies that the package ID is `k2qr.versus`, verifies the version, safely replaces the installed package, and then prompts the player to restart Geometry Dash.

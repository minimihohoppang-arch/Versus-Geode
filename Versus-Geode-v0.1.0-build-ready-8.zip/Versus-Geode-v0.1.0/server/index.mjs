import http from "node:http";
import crypto from "node:crypto";

const PORT = Number(process.env.PORT || 8787);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-6-astra";
const LATEST_VERSION = process.env.LATEST_VERSION || "v0.2.0";
const BOT_FALLBACK_MS = Math.max(2000, Number(process.env.BOT_FALLBACK_MS || 8000));

const waiting = [];
const tickets = new Map();
const rooms = new Map();

const LEVELS = {
  "Easy": [6508283],
  "Normal": [109254638],
  "Hard": [109171612],
  "Harder": [100157619],
  "Insane": [66142986],
  "Easy Demon": [13519],
  "Medium Demon": [34085027],
  "Hard Demon": [4284013],
  "Insane Demon": [4957691],
  "Extreme Demon": [61079355]
};

const BOT_NAMES = ["BOT NOVA", "BOT DASH", "BOT PULSE", "BOT PIXEL", "BOT ORBIT", "BOT WAVE", "BOT CUBE", "BOT NEON"];

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(body),
    "access-control-allow-origin": "*"
  });
  res.end(body);
}

async function readJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const text = Buffer.concat(chunks).toString("utf8");
  return text ? JSON.parse(text) : {};
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const pick = arr => arr[Math.floor(Math.random() * arr.length)];

function difficultyForRating(rating) {
  if (rating < 1000) return "Normal";
  if (rating < 1100) return "Easy";
  if (rating < 1205) return "Normal";
  if (rating < 1311) return "Hard";
  if (rating < 1500) return "Harder";
  if (rating < 1700) return "Insane";
  if (rating < 1900) return "Easy Demon";
  if (rating < 2100) return "Medium Demon";
  if (rating < 2350) return "Hard Demon";
  if (rating < 2700) return "Insane Demon";
  return "Extreme Demon";
}

function levelForDifficulty(difficulty) {
  return pick(LEVELS[difficulty] || LEVELS.Hard);
}

function removeWaiting(ticket) {
  const i = waiting.findIndex(x => x.ticket === ticket);
  if (i >= 0) waiting.splice(i, 1);
}

function createEntry(rating, playerName) {
  const ticket = crypto.randomUUID();
  const entry = {
    ticket,
    rating,
    playerName: String(playerName || "PLAYER").slice(0, 24),
    created: Date.now(),
    roomId: null,
    opponentTicket: null,
    result: null
  };
  tickets.set(ticket, entry);
  return entry;
}

function pairHuman(entry) {
  const opponentIndex = waiting.findIndex(x => x.ticket !== entry.ticket && Math.abs(x.rating - entry.rating) <= 250 && !x.roomId);
  if (opponentIndex < 0) return false;

  const opponent = waiting.splice(opponentIndex, 1)[0];
  removeWaiting(entry.ticket);

  const roomId = crypto.randomUUID();
  const average = Math.round((entry.rating + opponent.rating) / 2);
  const difficulty = difficultyForRating(average);
  const levelId = levelForDifficulty(difficulty);

  const room = {
    roomId,
    type: "human",
    difficulty,
    levelId,
    created: Date.now(),
    players: [entry.ticket, opponent.ticket]
  };
  rooms.set(roomId, room);

  entry.roomId = roomId;
  entry.opponentTicket = opponent.ticket;
  opponent.roomId = roomId;
  opponent.opponentTicket = entry.ticket;
  return true;
}

function makeBotMatch(entry) {
  removeWaiting(entry.ticket);
  const opponentRating = clamp(entry.rating + Math.round((Math.random() - 0.5) * 180), 1, 12999);
  const average = Math.round((entry.rating + opponentRating) / 2);
  const difficulty = difficultyForRating(average);
  const levelId = levelForDifficulty(difficulty);

  const expected = clamp(72 + (opponentRating - entry.rating) / 20 + (Math.random() * 16 - 8), 35, 100);
  const botCompleted = expected >= 96;
  return {
    opponentType: "bot",
    opponentName: pick(BOT_NAMES),
    opponentRating,
    difficulty,
    levelId,
    roomId: "",
    ticket: entry.ticket,
    botCompleted,
    botProgress: botCompleted ? 100 : expected,
    botDeaths: 1 + Math.floor(Math.random() * 6)
  };
}

function humanPayload(entry) {
  const room = rooms.get(entry.roomId);
  const opponent = tickets.get(entry.opponentTicket);
  return {
    opponentType: "human",
    opponentName: opponent?.playerName || "PLAYER",
    opponentRating: opponent?.rating || entry.rating,
    difficulty: room?.difficulty || difficultyForRating(entry.rating),
    levelId: room?.levelId || levelForDifficulty(difficultyForRating(entry.rating)),
    roomId: entry.roomId,
    ticket: entry.ticket,
    botCompleted: false,
    botProgress: 0,
    botDeaths: 0
  };
}

function compareResults(a, b) {
  if (a.completed !== b.completed) return a.completed ? 1 : -1;
  if (a.completed && b.completed) {
    if (a.deaths !== b.deaths) return a.deaths < b.deaths ? 1 : -1;
    return 0;
  }
  if (Math.abs(a.progress - b.progress) > 0.01) return a.progress > b.progress ? 1 : -1;
  if (a.deaths !== b.deaths) return a.deaths < b.deaths ? 1 : -1;
  return 0;
}

function resultStatus(roomId, ticket) {
  const room = rooms.get(roomId);
  const me = tickets.get(ticket);
  if (!room || !me || !room.players.includes(ticket)) return null;
  const opponentTicket = room.players.find(x => x !== ticket);
  const opponent = tickets.get(opponentTicket);
  if (!me.result || !opponent?.result) return { resolved: false };

  const cmp = compareResults(me.result, opponent.result);
  return {
    resolved: true,
    won: cmp >= 0,
    completed: me.result.completed,
    progress: me.result.progress,
    deaths: me.result.deaths,
    opponentRating: opponent.rating,
    opponentCompleted: opponent.result.completed,
    opponentProgress: opponent.result.progress,
    opponentDeaths: opponent.result.deaths
  };
}

async function findMatch(rating, playerName) {
  const entry = createEntry(rating, playerName);
  waiting.push(entry);
  pairHuman(entry);

  const deadline = Date.now() + BOT_FALLBACK_MS;
  while (!entry.roomId && Date.now() < deadline) {
    await sleep(250);
  }

  if (entry.roomId) return humanPayload(entry);
  return makeBotMatch(entry);
}

async function gptAnalyze(payload) {
  if (!OPENAI_API_KEY) return { enabled: false, reason: "OPENAI_API_KEY is not configured" };

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      reasoning: { effort: "low" },
      input: [
        {
          role: "system",
          content: [{ type: "input_text", text: "You are a Geometry Dash Versus skill analyst. Return short, practical skill observations. Do not override the deterministic rating algorithm." }]
        },
        {
          role: "user",
          content: [{ type: "input_text", text: JSON.stringify(payload) }]
        }
      ]
    })
  });

  if (!response.ok) throw new Error(`OpenAI ${response.status}`);
  const data = await response.json();
  return { enabled: true, model: OPENAI_MODEL, output: data.output_text || "" };
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (req.method === "OPTIONS") {
      res.writeHead(204, {
        "access-control-allow-origin": "*",
        "access-control-allow-methods": "GET,POST,OPTIONS",
        "access-control-allow-headers": "content-type"
      });
      return res.end();
    }

    if (req.method === "GET" && url.pathname === "/health") {
      return json(res, 200, { ok: true, waiting: waiting.length, rooms: rooms.size });
    }

    if (req.method === "GET" && url.pathname === "/v1/version") {
      return json(res, 200, { latestVersion: LATEST_VERSION });
    }

    if (req.method === "POST" && url.pathname === "/v1/match/find") {
      const body = await readJson(req);
      const rating = clamp(Number(body.rating || 1000), 1, 12999);
      return json(res, 200, await findMatch(rating, body.playerName));
    }

    if (req.method === "POST" && url.pathname === "/v1/match/result") {
      const body = await readJson(req);
      const roomId = String(body.roomId || "");
      const ticket = String(body.ticket || "");
      const room = rooms.get(roomId);
      const entry = tickets.get(ticket);
      if (!room || !entry || !room.players.includes(ticket)) return json(res, 404, { error: "unknown match" });

      entry.result = {
        completed: Boolean(body.completed),
        progress: clamp(Number(body.progress || 0), 0, 100),
        deaths: Math.max(0, Math.floor(Number(body.deaths || 0)))
      };
      return json(res, 200, resultStatus(roomId, ticket));
    }

    if (req.method === "GET" && url.pathname === "/v1/match/result/status") {
      const roomId = url.searchParams.get("roomId") || "";
      const ticket = url.searchParams.get("ticket") || "";
      const status = resultStatus(roomId, ticket);
      if (!status) return json(res, 404, { error: "unknown match" });
      return json(res, 200, status);
    }

    if (req.method === "POST" && url.pathname === "/v1/ai/analyze") {
      const body = await readJson(req);
      return json(res, 200, await gptAnalyze(body));
    }

    return json(res, 404, { error: "not found" });
  } catch (error) {
    return json(res, 500, { error: String(error?.message || error) });
  }
});

server.listen(PORT, () => {
  console.log(`Versus backend listening on :${PORT}`);
  console.log(`Human wait before bot fallback: ${BOT_FALLBACK_MS}ms`);
  console.log(`OpenAI model: ${OPENAI_MODEL} (${OPENAI_API_KEY ? "enabled" : "disabled"})`);
});

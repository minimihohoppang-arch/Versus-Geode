#include "MatchState.hpp"
#include "Profile.hpp"
#include <Geode/ui/GeodeUI.hpp>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <random>

using namespace geode::prelude;
using namespace geode::utils;

namespace versus {
namespace {

struct LevelChoice {
    PlayDifficulty difficulty;
    int levelId;
};

constexpr std::array<LevelChoice, 10> kDefaultLevels{{
    {PlayDifficulty::Easy, 6508283},          // ReTraY
    {PlayDifficulty::Normal, 109254638},      // Shimmer
    {PlayDifficulty::Hard, 109171612},        // Lunaris
    {PlayDifficulty::Harder, 100157619},      // Subwoofer Lullaby
    {PlayDifficulty::Insane, 66142986},       // Invert
    {PlayDifficulty::EasyDemon, 13519},       // The Nightmare
    {PlayDifficulty::MediumDemon, 34085027},  // B
    {PlayDifficulty::HardDemon, 4284013},     // Nine Circles
    {PlayDifficulty::InsaneDemon, 4957691},   // Windy Landscape
    {PlayDifficulty::ExtremeDemon, 61079355}  // Acu
}};

int defaultLevelFor(PlayDifficulty d) {
    for (auto const& item : kDefaultLevels) {
        if (item.difficulty == d) return item.levelId;
    }
    return 6508283;
}

PlayDifficulty parseDifficulty(std::string const& value) {
    if (value == "Easy") return PlayDifficulty::Easy;
    if (value == "Normal") return PlayDifficulty::Normal;
    if (value == "Hard") return PlayDifficulty::Hard;
    if (value == "Harder") return PlayDifficulty::Harder;
    if (value == "Insane") return PlayDifficulty::Insane;
    if (value == "Easy Demon") return PlayDifficulty::EasyDemon;
    if (value == "Medium Demon") return PlayDifficulty::MediumDemon;
    if (value == "Hard Demon") return PlayDifficulty::HardDemon;
    if (value == "Insane Demon") return PlayDifficulty::InsaneDemon;
    if (value == "Extreme Demon") return PlayDifficulty::ExtremeDemon;
    return PlayDifficulty::Hard;
}

std::string cleanBaseUrl() {
    auto base = Mod::get()->getSettingValue<std::string>("server-url");
    while (!base.empty() && base.back() == '/') base.pop_back();
    return base;
}

bool localWinsAgainstBot(bool completed, float progress, int deaths, MatchInfo const& bot) {
    if (completed != bot.botCompleted) return completed;
    if (completed && bot.botCompleted) return deaths <= bot.botDeaths;
    if (std::abs(progress - bot.botProgress) > 0.01f) return progress > bot.botProgress;
    return deaths <= bot.botDeaths;
}

void showResultPopup(bool won, int beforeRating, int afterRating, bool placed, int placementCount) {
    if (!placed) {
        FLAlertLayer::create(
            won ? "VICTORY" : "DEFEAT",
            fmt::format(
                "Match saved. Placement progress: <cg>{}/10</c>",
                placementCount
            ),
            "OK"
        )->show();
        return;
    }

    auto info = RankSystem::infoFor(afterRating);
    int delta = afterRating - beforeRating;
    FLAlertLayer::create(
        won ? "VICTORY" : "DEFEAT",
        fmt::format(
            "Result saved.\nRank: <cg>{}</c> ({})\nRating change: <cy>{:+d}</c>",
            info.displayRating,
            info.label,
            delta
        ),
        "OK"
    )->show();
}

} // namespace

MatchState& MatchState::get() {
    static MatchState instance;
    return instance;
}

void MatchState::startLocalBot(int myRating) {
    static std::mt19937 rng(std::random_device{}());
    std::uniform_int_distribution<int> ratingJitter(-90, 90);
    std::uniform_int_distribution<int> namePick(0, 7);
    std::uniform_real_distribution<float> noise(-8.f, 8.f);
    std::uniform_int_distribution<int> deathPick(1, 6);

    static constexpr std::array<char const*, 8> names{
        "BOT NOVA", "BOT DASH", "BOT PULSE", "BOT PIXEL",
        "BOT ORBIT", "BOT WAVE", "BOT CUBE", "BOT NEON"
    };

    int botRating = std::clamp(myRating + ratingJitter(rng), 1, RankSystem::kAbsoluteMax);
    auto difficulty = RankSystem::rouletteDifficulty(myRating, botRating);

    float expected = 72.f + static_cast<float>(botRating - myRating) / 20.f + noise(rng);
    expected = std::clamp(expected, 35.f, 100.f);
    bool completed = expected >= 96.f;

    m_match = {};
    m_match.active = true;
    m_match.bot = true;
    m_match.levelId = defaultLevelFor(difficulty);
    m_match.opponentRating = botRating;
    m_match.difficulty = difficulty;
    m_match.opponentName = names[static_cast<size_t>(namePick(rng))];
    m_match.botCompleted = completed;
    m_match.botProgress = completed ? 100.f : expected;
    m_match.botDeaths = deathPick(rng);
}

void MatchState::startFromServer(
    bool bot,
    int levelId,
    int opponentRating,
    PlayDifficulty difficulty,
    std::string opponentName,
    std::string roomId,
    std::string ticket,
    bool botCompleted,
    float botProgress,
    int botDeaths
) {
    m_match = {};
    m_match.active = true;
    m_match.bot = bot;
    m_match.levelId = levelId > 0 ? levelId : defaultLevelFor(difficulty);
    m_match.opponentRating = std::clamp(opponentRating, 1, RankSystem::kAbsoluteMax);
    m_match.difficulty = difficulty;
    m_match.opponentName = opponentName.empty() ? (bot ? "BOT" : "PLAYER") : std::move(opponentName);
    m_match.roomId = std::move(roomId);
    m_match.ticket = std::move(ticket);
    m_match.botCompleted = botCompleted;
    m_match.botProgress = std::clamp(botProgress, 0.f, 100.f);
    m_match.botDeaths = std::max(0, botDeaths);
}

void MatchState::clearActive() {
    m_match = {};
}

void MatchState::finishRun(bool completed, float progress, int deaths) {
    if (!m_match.active) return;
    progress = std::clamp(progress, 0.f, 100.f);
    deaths = std::max(0, deaths);

    if (m_match.bot) {
        resolveBot(completed, progress, deaths);
    } else {
        submitHuman(completed, progress, deaths);
    }
}

void MatchState::resolveBot(bool completed, float progress, int deaths) {
    auto current = m_match;
    bool won = localWinsAgainstBot(completed, progress, deaths, current);

    MatchRecord record;
    record.won = won;
    record.completed = completed;
    record.progress = progress;
    record.deaths = deaths;
    record.opponentRating = current.opponentRating;
    record.difficulty = current.difficulty;

    auto& profile = Profile::get();
    int before = profile.rating();
    profile.applyRankedResult(record);
    int after = profile.rating();
    bool placed = profile.placed();
    int placement = profile.placementCount();

    clearActive();
    showResultPopup(won, before, after, placed, placement);
}

void MatchState::savePendingHuman(bool pending) {
    auto mod = Mod::get();
    mod->setSavedValue("pending-human", pending);
    if (pending) {
        mod->setSavedValue("pending-room", m_match.roomId);
        mod->setSavedValue("pending-ticket", m_match.ticket);
        mod->setSavedValue("pending-opponent-rating", m_match.opponentRating);
        mod->setSavedValue("pending-difficulty", static_cast<int>(m_match.difficulty));
    } else {
        mod->setSavedValue("pending-room", std::string{});
        mod->setSavedValue("pending-ticket", std::string{});
    }
    (void)mod->saveData();
}

void MatchState::submitHuman(bool completed, float progress, int deaths) {
    auto base = cleanBaseUrl();
    if (base.empty() || m_match.roomId.empty() || m_match.ticket.empty()) {
        // If the server disappears after a human match was created, do not throw away the run.
        // Convert the opponent to a fair local bot and resolve immediately.
        m_match.bot = true;
        m_match.opponentName = "BOT FALLBACK";
        m_match.botCompleted = false;
        m_match.botProgress = std::clamp(65.f + static_cast<float>(m_match.opponentRating - Profile::get().rating()) / 25.f, 35.f, 95.f);
        m_match.botDeaths = 3;
        resolveBot(completed, progress, deaths);
        return;
    }

    matjson::Value body;
    body["roomId"] = m_match.roomId;
    body["ticket"] = m_match.ticket;
    body["completed"] = completed;
    body["progress"] = progress;
    body["deaths"] = deaths;

    auto submitted = m_match;
    web::WebRequest req;
    req.timeout(std::chrono::seconds(10));
    req.bodyJSON(body);
    m_resultTask.spawn(req.post(base + "/v1/match/result", Mod::get()), [this, submitted, completed, progress, deaths](web::WebResponse response) {
        if (!response.ok()) {
            // Server failed at result time: preserve play by falling back to a bot result.
            m_match = submitted;
            m_match.bot = true;
            m_match.opponentName = "BOT FALLBACK";
            m_match.botCompleted = false;
            m_match.botProgress = std::clamp(65.f + static_cast<float>(submitted.opponentRating - Profile::get().rating()) / 25.f, 35.f, 95.f);
            m_match.botDeaths = 3;
            resolveBot(completed, progress, deaths);
            return;
        }

        auto json = response.json();
        if (json.isErr()) return;
        auto value = json.unwrap();
        bool resolved = value.get<bool>("resolved").unwrapOr(false);
        if (!resolved) {
            m_match = submitted;
            savePendingHuman(true);
            clearActive();
            FLAlertLayer::create(
                "RESULT SUBMITTED",
                "Your run is saved. The other player is still playing. Open Versus again to collect the result.",
                "OK"
            )->show();
            return;
        }

        bool won = value.get<bool>("won").unwrapOr(false);
        int oppRating = value.get<int>("opponentRating").unwrapOr(submitted.opponentRating);
        applyResolvedHuman(won, completed, progress, deaths, oppRating, submitted.difficulty);
        savePendingHuman(false);
        clearActive();
    });
}

void MatchState::applyResolvedHuman(bool won, bool completed, float progress, int deaths, int opponentRating, PlayDifficulty difficulty) {
    MatchRecord record;
    record.won = won;
    record.completed = completed;
    record.progress = progress;
    record.deaths = deaths;
    record.opponentRating = opponentRating;
    record.difficulty = difficulty;

    auto& profile = Profile::get();
    int before = profile.rating();
    profile.applyRankedResult(record);
    int after = profile.rating();
    showResultPopup(won, before, after, profile.placed(), profile.placementCount());
}

void MatchState::checkPendingHumanResult() {
    auto mod = Mod::get();
    if (!mod->getSavedValue<bool>("pending-human", false)) return;

    auto base = cleanBaseUrl();
    auto room = mod->getSavedValue<std::string>("pending-room", "");
    auto ticket = mod->getSavedValue<std::string>("pending-ticket", "");
    int oppRating = mod->getSavedValue<int>("pending-opponent-rating", 1000);
    auto difficulty = static_cast<PlayDifficulty>(std::clamp(mod->getSavedValue<int>("pending-difficulty", 3), 1, 10));
    if (base.empty() || room.empty() || ticket.empty()) return;

    web::WebRequest req;
    req.timeout(std::chrono::seconds(7));
    auto url = fmt::format("{}/v1/match/result/status?roomId={}&ticket={}", base, room, ticket);
    m_pendingTask.spawn(req.get(url, Mod::get()), [this, oppRating, difficulty](web::WebResponse response) {
        if (!response.ok()) return;
        auto json = response.json();
        if (json.isErr()) return;
        auto value = json.unwrap();
        if (!value.get<bool>("resolved").unwrapOr(false)) return;

        bool won = value.get<bool>("won").unwrapOr(false);
        bool completed = value.get<bool>("completed").unwrapOr(false);
        float progress = value.get<double>("progress").unwrapOr(0.0);
        int deaths = value.get<int>("deaths").unwrapOr(0);
        int serverOppRating = value.get<int>("opponentRating").unwrapOr(oppRating);

        applyResolvedHuman(won, completed, progress, deaths, serverOppRating, difficulty);
        savePendingHuman(false);
    });
}

} // namespace versus

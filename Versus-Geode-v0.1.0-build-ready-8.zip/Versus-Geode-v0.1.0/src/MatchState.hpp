#pragma once
#include "RankSystem.hpp"
#include <Geode/Geode.hpp>
#include <Geode/utils/web.hpp>
#include <string>

namespace versus {

struct MatchInfo {
    bool active = false;
    bool bot = true;
    int levelId = 6508283;
    int opponentRating = 1000;
    PlayDifficulty difficulty = PlayDifficulty::Easy;
    std::string opponentName = "BOT";
    std::string roomId;
    std::string ticket;

    bool botCompleted = false;
    float botProgress = 0.f;
    int botDeaths = 0;
};

class MatchState {
public:
    static MatchState& get();

    bool active() const { return m_match.active; }
    MatchInfo const& info() const { return m_match; }
    int levelId() const { return m_match.levelId; }

    void startLocalBot(int myRating);
    void startFromServer(
        bool bot,
        int levelId,
        int opponentRating,
        PlayDifficulty difficulty,
        std::string opponentName,
        std::string roomId,
        std::string ticket,
        bool botCompleted,
        float botProgress,
        int botDeaths
    );

    void finishRun(bool completed, float progress, int deaths);
    void checkPendingHumanResult();
    void clearActive();

private:
    MatchInfo m_match;
    geode::async::TaskHolder<geode::utils::web::WebResponse> m_resultTask;
    geode::async::TaskHolder<geode::utils::web::WebResponse> m_pendingTask;

    MatchState() = default;

    void resolveBot(bool completed, float progress, int deaths);
    void submitHuman(bool completed, float progress, int deaths);
    void applyResolvedHuman(bool won, bool completed, float progress, int deaths, int opponentRating, PlayDifficulty difficulty);
    void savePendingHuman(bool pending);
};

} // namespace versus

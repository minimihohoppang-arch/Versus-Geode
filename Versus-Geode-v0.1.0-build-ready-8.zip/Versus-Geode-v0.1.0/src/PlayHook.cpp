#include "MatchState.hpp"
#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <algorithm>

using namespace geode::prelude;

class $modify(VersusPlayLayer, PlayLayer) {
    struct Fields {
        bool tracked = false;
        bool resolved = false;
        int deaths = 0;
    };

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;

        auto& match = versus::MatchState::get();
        if (match.active() && level && level->m_levelID.value() == match.levelId()) {
            m_fields->tracked = true;
            m_fields->resolved = false;
            m_fields->deaths = 0;

            auto label = CCLabelBMFont::create("VERSUS - ONE RUN", "bigFont.fnt");
            if (label) {
                auto win = CCDirector::sharedDirector()->getWinSize();
                label->setScale(.35f);
                label->setOpacity(190);
                label->setPosition({win.width / 2.f, win.height - 14.f});
                label->setZOrder(1000);
                this->addChild(label);
            }
        }
        return true;
    }

    void destroyPlayer(PlayerObject* player, GameObject* object) {
        bool shouldResolve = m_fields->tracked && !m_fields->resolved;
        float progress = shouldResolve ? std::clamp(this->getCurrentPercent(), 0.f, 100.f) : 0.f;
        if (shouldResolve) {
            m_fields->resolved = true;
            m_fields->deaths += 1;
        }

        PlayLayer::destroyPlayer(player, object);

        if (shouldResolve) {
            versus::MatchState::get().finishRun(false, progress, m_fields->deaths);
        }
    }

    void levelComplete() {
        bool shouldResolve = m_fields->tracked && !m_fields->resolved;
        if (shouldResolve) m_fields->resolved = true;

        PlayLayer::levelComplete();

        if (shouldResolve) {
            versus::MatchState::get().finishRun(true, 100.f, m_fields->deaths);
        }
    }
};

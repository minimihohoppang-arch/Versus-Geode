# Versus v0.3.1 build source

This source package embeds the official Google Apps Script update endpoint and Drive folder configuration. It still requires GitHub Actions compilation to produce a real `.geode` file.

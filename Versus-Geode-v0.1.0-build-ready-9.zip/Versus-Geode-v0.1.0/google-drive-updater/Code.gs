const VERSUS_FOLDER_ID = '1PQlaFMqYwv6f04l_T4BwQRF6iquJM_60';
const FILE_PATTERN = /^k2qr\.versus-v(\d+)\.(\d+)\.(\d+)\.geode$/i;

function doGet() {
  try {
    if (VERSUS_FOLDER_ID === 'PASTE_GOOGLE_DRIVE_FOLDER_ID_HERE') {
      return json_({
        ok: false,
        error: 'VERSUS_FOLDER_ID is not configured.'
      });
    }

    const folder = DriveApp.getFolderById(VERSUS_FOLDER_ID);
    const files = folder.getFiles();
    let best = null;

    while (files.hasNext()) {
      const file = files.next();
      const match = file.getName().match(FILE_PATTERN);
      if (!match) continue;

      const version = [Number(match[1]), Number(match[2]), Number(match[3])];
      if (!best || compareVersion_(version, best.version) > 0) {
        best = { file, version };
      }
    }

    if (!best) {
      return json_({
        ok: false,
        error: 'No Versus .geode file was found. Expected a name like k2qr.versus-v0.3.1.geode.'
      });
    }

    const file = best.file;
    const bytes = file.getBlob().getBytes();
    const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, bytes);
    const sha256 = digest.map(function(b) {
      const value = b < 0 ? b + 256 : b;
      return ('0' + value.toString(16)).slice(-2);
    }).join('');

    const versionText = 'v' + best.version.join('.');

    return json_({
      ok: true,
      version: versionText,
      downloadUrl: 'https://drive.google.com/uc?export=download&id=' + encodeURIComponent(file.getId()),
      sha256: sha256,
      notes: file.getDescription() || '',
      fileName: file.getName(),
      updatedAt: file.getLastUpdated().toISOString()
    });
  } catch (e) {
    return json_({
      ok: false,
      error: String(e && e.message ? e.message : e)
    });
  }
}

function compareVersion_(a, b) {
  for (let i = 0; i < 3; i++) {
    if (a[i] !== b[i]) return a[i] > b[i] ? 1 : -1;
  }
  return 0;
}

function json_(value) {
  return ContentService
    .createTextOutput(JSON.stringify(value))
    .setMimeType(ContentService.MimeType.JSON);
}

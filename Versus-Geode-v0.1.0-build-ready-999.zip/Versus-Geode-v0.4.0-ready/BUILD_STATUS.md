# Versus v0.4.0 build source

Prepared changes:

- TEST ROUND removed.
- Main queue button renamed to MATCHMAKING.
- Matchmaking uses the configured Google Apps Script web app as a real online service.
- Human opponents are preferred; after the server wait window a bot is returned automatically.
- Pressing MATCHMAKING does not change rating. Rating changes only after an actual played match result.
- Jukebox detection now uses Geode Loader install/load state for `fleym.nongd`.
- Automatic update checks remain enabled and a manual CHECK UPDATE button is always available.
- Google Apps Script `Code.gs` now provides update manifest, health check, matchmaking, result submission and pending-result lookup.

Important: this is source, not a renamed ZIP. GitHub Actions must compile it before a real `.geode` exists. The Apps Script code must also be pasted into the existing project and the web app deployment updated to a new version for online matchmaking to work.

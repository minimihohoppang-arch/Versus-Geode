# Versus

Ranked Geometry Dash Versus for K2QR.

- `MATCHMAKING` searches for a real player first.
- If no player is available after the matchmaking window, a bot joins automatically.
- Ranked points are applied only after an actual played match result.
- Online matchmaking and update checks use the configured Google Apps Script endpoint.
- Google Drive releases are checked automatically when Versus opens, and can also be checked with `CHECK UPDATE`.
- Jukebox integration detects `fleym.nongd` through Geode instead of always showing an install prompt.

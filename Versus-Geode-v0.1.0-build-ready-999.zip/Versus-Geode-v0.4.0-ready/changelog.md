# v0.4.0

- Split update and matchmaking endpoints.
- Official matchmaking endpoint is now configured separately from Google Drive updates.
- Jukebox is detected at runtime instead of being a hard dependency.

# v0.4.0

- Replaced TEST ROUND with real `MATCHMAKING`.
- Matchmaking now checks the online Apps Script server for a human first, then falls back to a bot after the wait window.
- Pressing matchmaking no longer changes rating by itself; rating changes only after a played result.
- Added live server health checks and a built-in default server URL.
- Fixed Jukebox detection by checking whether `fleym.nongd` is actually installed and loaded.
- Added a permanent `CHECK UPDATE` button and clearer update-check errors / up-to-date status.
- Kept automatic Google Drive update prompts for newer versions.

## v0.3.1
- Embedded the official Google Apps Script update endpoint as the default update service.
- Added a hardcoded fallback so existing installs with a blank update URL still check for updates automatically.
- Preconfigured the included Apps Script source with the Versus Updates Google Drive folder ID.
- Google Drive update verification and safe package replacement from v0.3.0 remain enabled.

## v0.3.0
- Added Google Drive update checks through a configurable Google Apps Script web app.
- Added automatic Update Available popup when entering Versus.
- Added direct .geode download, SHA-256 verification, package ID/version validation, safe replacement, and restart prompt.
- Human matchmaking and bot fallback from v0.2.0 remain enabled.

# Changelog

## v0.2.0
- Added real human matchmaking protocol through the Versus backend.
- Added automatic bot fallback when no human is found or the server is unavailable.
- Added rank-aware level roulette with Auto/None excluded.
- Added PLAY MATCH flow that opens the exact selected level ID.
- Added one-run gameplay tracking through PlayLayer.
- Added bot result comparison and automatic rank/placement updates.
- Added human result submission and pending-result collection.

## v0.1.0
- Initial prototype.

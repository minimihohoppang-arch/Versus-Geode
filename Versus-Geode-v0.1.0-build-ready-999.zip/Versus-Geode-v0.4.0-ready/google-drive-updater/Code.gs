const VERSUS_FOLDER_ID = '1PQlaFMqYwv6f04l_T4BwQRF6iquJM_60';
const FILE_PATTERN = /^k2qr\.versus-v(\d+)\.(\d+)\.(\d+)\.geode$/i;

const STATE_KEY = 'VERSUS_MATCHMAKING_STATE_V2';
const MATCH_RANGE = 250;
const MATCH_WAIT_MS = 8000;
const QUEUE_TTL_MS = 15000;
const ROOM_TTL_MS = 60 * 60 * 1000;

function doGet(e) {
  try {
    const action = String((e && e.parameter && e.parameter.action) || 'manifest');
    if (action === 'health') {
      const state = loadState_();
      return json_({
        ok: true,
        serverOnline: true,
        service: 'K2QR Versus',
        queueSize: state.queue.length,
        serverTime: new Date().toISOString()
      });
    }
    return updateManifest_();
  } catch (err) {
    return json_({ ok: false, error: errorText_(err) });
  }
}

function doPost(e) {
  try {
    const body = parseBody_(e);
    const action = String(body.action || '');

    if (action === 'findMatch') return json_(findMatch_(body));
    if (action === 'submitResult') return json_(submitResult_(body));
    if (action === 'resultStatus') return json_(resultStatus_(body));

    return json_({ ok: false, error: 'Unknown Versus server action.' });
  } catch (err) {
    return json_({ ok: false, error: errorText_(err) });
  }
}

function updateManifest_() {
  const folder = DriveApp.getFolderById(VERSUS_FOLDER_ID);
  const files = folder.getFiles();
  let best = null;

  while (files.hasNext()) {
    const file = files.next();
    const match = file.getName().match(FILE_PATTERN);
    if (!match) continue;

    const version = [Number(match[1]), Number(match[2]), Number(match[3])];
    if (!best || compareVersion_(version, best.version) > 0) {
      best = { file: file, version: version };
    }
  }

  if (!best) {
    return json_({
      ok: false,
      error: 'No Versus .geode file was found. Use a name like k2qr.versus-v0.4.0.geode.'
    });
  }

  const file = best.file;
  const bytes = file.getBlob().getBytes();
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, bytes);
  const sha256 = digest.map(function(b) {
    const value = b < 0 ? b + 256 : b;
    return ('0' + value.toString(16)).slice(-2);
  }).join('');

  return json_({
    ok: true,
    version: 'v' + best.version.join('.'),
    downloadUrl: 'https://drive.google.com/uc?export=download&id=' + encodeURIComponent(file.getId()),
    sha256: sha256,
    notes: file.getDescription() || '',
    fileName: file.getName(),
    updatedAt: file.getLastUpdated().toISOString()
  });
}

function findMatch_(body) {
  const clientId = safeId_(body.clientId);
  const playerName = safeName_(body.playerName || 'PLAYER');
  const rating = clamp_(Number(body.rating) || 1000, 1, 10000);
  const placed = Boolean(body.placed);

  if (!clientId) return { ok: false, error: 'Missing client ID.' };

  const lock = LockService.getScriptLock();
  lock.waitLock(5000);
  let state;
  try {
    state = loadState_();
    cleanupState_(state);

    // A new matchmaking request supersedes any old assignment for this client.
    delete state.assignments[clientId];
    state.queue = state.queue.filter(function(q) { return q.clientId !== clientId; });

    let bestIndex = -1;
    let bestDelta = 999999;
    for (let i = 0; i < state.queue.length; i++) {
      const q = state.queue[i];
      if (!q || q.clientId === clientId) continue;
      const delta = Math.abs(Number(q.rating || 1000) - rating);
      if (delta <= MATCH_RANGE && delta < bestDelta) {
        bestIndex = i;
        bestDelta = delta;
      }
    }

    if (bestIndex >= 0) {
      const other = state.queue.splice(bestIndex, 1)[0];
      const roomId = token_('room');
      const ticketA = token_('a');
      const ticketB = token_('b');
      const selected = chooseLevel_(Math.round((rating + Number(other.rating || 1000)) / 2));
      const now = Date.now();

      state.rooms[roomId] = {
        roomId: roomId,
        createdAt: now,
        updatedAt: now,
        levelId: selected.levelId,
        difficulty: selected.difficulty,
        resolved: false,
        players: {
          a: {
            clientId: other.clientId,
            name: other.playerName,
            rating: Number(other.rating || 1000),
            placed: Boolean(other.placed),
            ticket: ticketA
          },
          b: {
            clientId: clientId,
            name: playerName,
            rating: rating,
            placed: placed,
            ticket: ticketB
          }
        },
        results: { a: null, b: null },
        outcome: null
      };

      state.assignments[other.clientId] = makeHumanAssignment_(state.rooms[roomId], 'a');
      state.assignments[clientId] = makeHumanAssignment_(state.rooms[roomId], 'b');
      saveState_(state);
      return Object.assign({ ok: true }, state.assignments[clientId]);
    }

    state.queue.push({
      clientId: clientId,
      playerName: playerName,
      rating: rating,
      placed: placed,
      joinedAt: Date.now()
    });
    saveState_(state);
  } finally {
    lock.releaseLock();
  }

  const deadline = Date.now() + MATCH_WAIT_MS;
  while (Date.now() < deadline) {
    Utilities.sleep(500);
    const current = loadState_();
    const assignment = current.assignments && current.assignments[clientId];
    if (assignment) return Object.assign({ ok: true }, assignment);
  }

  const timeoutLock = LockService.getScriptLock();
  timeoutLock.waitLock(5000);
  try {
    state = loadState_();
    cleanupState_(state);
    if (state.assignments[clientId]) {
      const assignment = state.assignments[clientId];
      saveState_(state);
      return Object.assign({ ok: true }, assignment);
    }
    state.queue = state.queue.filter(function(q) { return q.clientId !== clientId; });
    saveState_(state);
  } finally {
    timeoutLock.releaseLock();
  }

  return Object.assign({ ok: true }, makeBotAssignment_(rating));
}

function submitResult_(body) {
  const roomId = safeId_(body.roomId);
  const ticket = safeId_(body.ticket);
  if (!roomId || !ticket) return { ok: false, error: 'Missing room ticket.' };

  const lock = LockService.getScriptLock();
  lock.waitLock(5000);
  try {
    const state = loadState_();
    cleanupState_(state);
    const room = state.rooms[roomId];
    if (!room) return { ok: false, error: 'This Versus room has expired.' };

    const side = sideForTicket_(room, ticket);
    if (!side) return { ok: false, error: 'Invalid Versus room ticket.' };

    room.results[side] = {
      completed: Boolean(body.completed),
      progress: clamp_(Number(body.progress) || 0, 0, 100),
      deaths: Math.max(0, Math.floor(Number(body.deaths) || 0)),
      submittedAt: Date.now()
    };
    room.updatedAt = Date.now();

    if (room.results.a && room.results.b && !room.resolved) {
      const cmp = compareRuns_(room.results.a, room.results.b, room.players.a.ticket, room.players.b.ticket);
      room.resolved = true;
      room.outcome = {
        aWon: cmp > 0,
        bWon: cmp < 0,
        resolvedAt: Date.now()
      };
    }

    state.rooms[roomId] = room;
    saveState_(state);
    return statusFor_(room, side);
  } finally {
    lock.releaseLock();
  }
}

function resultStatus_(body) {
  const roomId = safeId_(body.roomId);
  const ticket = safeId_(body.ticket);
  if (!roomId || !ticket) return { ok: false, error: 'Missing room ticket.' };

  const state = loadState_();
  cleanupState_(state);
  const room = state.rooms[roomId];
  if (!room) return { ok: false, error: 'This Versus room has expired.' };

  const side = sideForTicket_(room, ticket);
  if (!side) return { ok: false, error: 'Invalid Versus room ticket.' };
  return statusFor_(room, side);
}

function statusFor_(room, side) {
  const otherSide = side === 'a' ? 'b' : 'a';
  const own = room.results[side];
  const other = room.players[otherSide];
  const resolved = Boolean(room.resolved && room.outcome && own);

  return {
    ok: true,
    resolved: resolved,
    won: resolved ? Boolean(side === 'a' ? room.outcome.aWon : room.outcome.bWon) : false,
    completed: own ? Boolean(own.completed) : false,
    progress: own ? Number(own.progress || 0) : 0,
    deaths: own ? Number(own.deaths || 0) : 0,
    opponentRating: Number(other.rating || 1000)
  };
}

function makeHumanAssignment_(room, side) {
  const otherSide = side === 'a' ? 'b' : 'a';
  const me = room.players[side];
  const other = room.players[otherSide];
  return {
    opponentType: 'human',
    roomId: room.roomId,
    ticket: me.ticket,
    opponentName: other.name,
    opponentRating: Number(other.rating || 1000),
    difficulty: room.difficulty,
    levelId: Number(room.levelId),
    botCompleted: false,
    botProgress: 0,
    botDeaths: 0
  };
}

function makeBotAssignment_(rating) {
  const names = ['BOT NOVA', 'BOT DASH', 'BOT PULSE', 'BOT PIXEL', 'BOT ORBIT', 'BOT WAVE', 'BOT CUBE', 'BOT NEON'];
  const botRating = clamp_(rating + randomInt_(-90, 90), 1, 10000);
  const selected = chooseLevel_(Math.round((rating + botRating) / 2));
  let expected = 72 + (botRating - rating) / 20 + randomInt_(-8, 8);
  expected = clamp_(expected, 35, 100);
  const completed = expected >= 96;

  return {
    opponentType: 'bot',
    roomId: '',
    ticket: '',
    opponentName: names[randomInt_(0, names.length - 1)],
    opponentRating: botRating,
    difficulty: selected.difficulty,
    levelId: selected.levelId,
    botCompleted: completed,
    botProgress: completed ? 100 : expected,
    botDeaths: randomInt_(1, 6)
  };
}

function chooseLevel_(rating) {
  if (rating < 1100) return { difficulty: 'Easy', levelId: 6508283 };
  if (rating < 1205) return { difficulty: 'Normal', levelId: 109254638 };
  if (rating < 1311) return { difficulty: 'Hard', levelId: 109171612 };
  if (rating < 1450) return { difficulty: 'Harder', levelId: 100157619 };
  if (rating < 1700) return { difficulty: 'Insane', levelId: 66142986 };
  if (rating < 1900) return { difficulty: 'Easy Demon', levelId: 13519 };
  if (rating < 2100) return { difficulty: 'Medium Demon', levelId: 34085027 };
  if (rating < 2350) return { difficulty: 'Hard Demon', levelId: 4284013 };
  if (rating < 2700) return { difficulty: 'Insane Demon', levelId: 4957691 };
  return { difficulty: 'Extreme Demon', levelId: 61079355 };
}

function compareRuns_(a, b, ticketA, ticketB) {
  if (Boolean(a.completed) !== Boolean(b.completed)) return a.completed ? 1 : -1;
  if (a.completed && b.completed && Number(a.deaths) !== Number(b.deaths)) {
    return Number(a.deaths) < Number(b.deaths) ? 1 : -1;
  }
  if (Math.abs(Number(a.progress) - Number(b.progress)) > 0.01) {
    return Number(a.progress) > Number(b.progress) ? 1 : -1;
  }
  if (Number(a.deaths) !== Number(b.deaths)) return Number(a.deaths) < Number(b.deaths) ? 1 : -1;
  // Exact ties are broken deterministically so Ranked never awards both players a win.
  return String(ticketA) < String(ticketB) ? 1 : -1;
}

function sideForTicket_(room, ticket) {
  if (room.players && room.players.a && room.players.a.ticket === ticket) return 'a';
  if (room.players && room.players.b && room.players.b.ticket === ticket) return 'b';
  return '';
}

function cleanupState_(state) {
  const now = Date.now();
  state.queue = (state.queue || []).filter(function(q) {
    return q && q.clientId && now - Number(q.joinedAt || 0) <= QUEUE_TTL_MS;
  });
  state.rooms = state.rooms || {};
  state.assignments = state.assignments || {};

  Object.keys(state.rooms).forEach(function(roomId) {
    const room = state.rooms[roomId];
    if (!room || now - Number(room.updatedAt || room.createdAt || 0) > ROOM_TTL_MS) {
      if (room && room.players) {
        if (room.players.a) delete state.assignments[room.players.a.clientId];
        if (room.players.b) delete state.assignments[room.players.b.clientId];
      }
      delete state.rooms[roomId];
    }
  });
}

function loadState_() {
  const raw = PropertiesService.getScriptProperties().getProperty(STATE_KEY);
  if (!raw) return { queue: [], rooms: {}, assignments: {} };
  try {
    const parsed = JSON.parse(raw);
    parsed.queue = parsed.queue || [];
    parsed.rooms = parsed.rooms || {};
    parsed.assignments = parsed.assignments || {};
    return parsed;
  } catch (_) {
    return { queue: [], rooms: {}, assignments: {} };
  }
}

function saveState_(state) {
  PropertiesService.getScriptProperties().setProperty(STATE_KEY, JSON.stringify(state));
}

function parseBody_(e) {
  if (!e || !e.postData || !e.postData.contents) return {};
  return JSON.parse(e.postData.contents);
}

function safeId_(value) {
  return String(value || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 120);
}

function safeName_(value) {
  const name = String(value || 'PLAYER').replace(/[<>\r\n]/g, '').trim().slice(0, 24);
  return name || 'PLAYER';
}

function token_(prefix) {
  return prefix + '_' + Utilities.getUuid().replace(/-/g, '');
}

function randomInt_(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function clamp_(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function compareVersion_(a, b) {
  for (let i = 0; i < 3; i++) {
    if (a[i] !== b[i]) return a[i] > b[i] ? 1 : -1;
  }
  return 0;
}

function errorText_(err) {
  return String(err && err.message ? err.message : err);
}

function json_(value) {
  return ContentService
    .createTextOutput(JSON.stringify(value))
    .setMimeType(ContentService.MimeType.JSON);
}

# Versus v0.4.0 Google Apps Script server + updater

This one Apps Script web app provides both:

- Google Drive update manifest
- live human-first matchmaking with automatic bot fallback
- human match result settlement / pending result lookup
- server health status

## Deploy

1. Open the existing Versus Apps Script project.
2. Replace all code in `Code.gs` with the new `Code.gs` from this folder.
3. Save.
4. Deploy -> Manage deployments.
5. Edit the current Web app deployment and select **New version**.
6. Execute as: **Me**.
7. Who has access: **Anyone**.
8. Deploy. Keep the same `/exec` URL.

The configured endpoint is already built into Versus v0.4.0.

## Update files

Upload compiled releases to the Drive folder with this exact naming pattern:

`k2qr.versus-vMAJOR.MINOR.PATCH.geode`

Example: `k2qr.versus-v0.4.0.geode`

When a newer version exists, opening Versus automatically checks the manifest and shows `Update Available!`. The `CHECK UPDATE` button can also force a manual check.

## Matchmaking behavior

`MATCHMAKING` searches for a human opponent within about +/-250 rating for 8 seconds. If another player is waiting, both are assigned the same level and a private result ticket. If nobody is available, a bot is returned automatically. Rating changes happen only after a played match result is resolved.

This Apps Script backend is intended for a small community/prototype. It is not a hardened anti-cheat or high-scale production service.

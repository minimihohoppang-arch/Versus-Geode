# Versus Matchmaking Server

Web app URL:
https://script.google.com/macros/s/AKfycbyAEBRk-Lsv4a81JWbtOjkDOa4XD6ns3JemrqEDu7xw-tR2DRS7qn_RaoTAuzL_QFVx/exec

Replace the test Code.gs in the separate Matchmaking Apps Script project with Code.gs from this folder, then update the existing web-app deployment to a new version.

The Google Drive update service remains separate:
https://script.google.com/macros/s/AKfycbzwR4Nm76NM-54si1RgVH7K_rWYMAdJ1wa1rBqx6wyAw5GclV90JPmx-CBjMRXNuCBrOQ/exec

#include "VersusLayer.hpp"
#include "MatchState.hpp"
#include "Profile.hpp"
#include "RankSystem.hpp"
#include <Geode/ui/GeodeUI.hpp>
#include <Geode/utils/general.hpp>
#include <Geode/utils/file.hpp>
#include <Geode/utils/hash.hpp>
#include <Geode/loader/ModMetadata.hpp>
#include <Geode/binding/GJDifficultySprite.hpp>
#include <Geode/binding/GJSearchObject.hpp>
#include <Geode/binding/LevelBrowserLayer.hpp>
#include <algorithm>
#include <array>
#include <chrono>
#include <filesystem>
#include <system_error>
#include <random>

using namespace geode::prelude;
using namespace geode::utils;

namespace {
std::array<int, 3> parseVersion3(std::string value) {
    if (!value.empty() && (value[0] == 'v' || value[0] == 'V')) value.erase(value.begin());
    std::array<int, 3> out{0, 0, 0};
    size_t start = 0;
    for (int i = 0; i < 3; ++i) {
        auto end = value.find('.', start);
        auto part = value.substr(start, end == std::string::npos ? std::string::npos : end - start);
        out[i] = geode::utils::numFromString<int>(part).unwrapOr(0);
        if (end == std::string::npos) break;
        start = end + 1;
    }
    return out;
}

bool newerThanCurrent(std::string const& latest) {
    auto current = Mod::get()->getVersion().toVString();
    return parseVersion3(latest) > parseVersion3(current);
}

std::string getClientId() {
    auto mod = Mod::get();
    auto saved = mod->getSavedValue<std::string>("match-client-id", "");
    if (!saved.empty()) return saved;

    static std::mt19937_64 rng(std::random_device{}());
    auto now = static_cast<unsigned long long>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()
        ).count()
    );
    auto created = fmt::format("{:x}{:x}", now, rng());
    mod->setSavedValue("match-client-id", created);
    (void)mod->saveData();
    return created;
}

versus::PlayDifficulty parseDifficulty(std::string const& value) {
    if (value == "Easy") return versus::PlayDifficulty::Easy;
    if (value == "Normal") return versus::PlayDifficulty::Normal;
    if (value == "Hard") return versus::PlayDifficulty::Hard;
    if (value == "Harder") return versus::PlayDifficulty::Harder;
    if (value == "Insane") return versus::PlayDifficulty::Insane;
    if (value == "Easy Demon") return versus::PlayDifficulty::EasyDemon;
    if (value == "Medium Demon") return versus::PlayDifficulty::MediumDemon;
    if (value == "Hard Demon") return versus::PlayDifficulty::HardDemon;
    if (value == "Insane Demon") return versus::PlayDifficulty::InsaneDemon;
    if (value == "Extreme Demon") return versus::PlayDifficulty::ExtremeDemon;
    return versus::PlayDifficulty::Hard;
}
}

VersusLayer* VersusLayer::create() {
    auto ret = new VersusLayer();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

CCScene* VersusLayer::scene() {
    auto scene = CCScene::create();
    scene->addChild(VersusLayer::create());
    return scene;
}

bool VersusLayer::init() {
    if (!CCLayer::init()) return false;

    auto win = CCDirector::sharedDirector()->getWinSize();

    auto bg = CCSprite::create("GJ_gradientBG.png");
    if (bg) {
        bg->setAnchorPoint({0, 0});
        bg->setPosition({0, 0});
        bg->setScaleX(win.width / bg->getContentSize().width);
        bg->setScaleY(win.height / bg->getContentSize().height);
        bg->setColor({25, 40, 80});
        addChild(bg, -10);
    }

    auto title = CCLabelBMFont::create("VERSUS", "bigFont.fnt");
    title->setPosition({win.width / 2.f, win.height - 34.f});
    title->setScale(.8f);
    addChild(title);

    m_rankLabel = CCLabelBMFont::create("UNRANKED", "bigFont.fnt");
    m_rankLabel->setScale(.62f);
    m_rankLabel->setPosition({win.width / 2.f, win.height - 92.f});
    addChild(m_rankLabel);

    m_tierLabel = CCLabelBMFont::create("PLACEMENT", "goldFont.fnt");
    m_tierLabel->setScale(.45f);
    m_tierLabel->setPosition({win.width / 2.f, win.height - 118.f});
    addChild(m_tierLabel);

    m_statusLabel = CCLabelBMFont::create("", "chatFont.fnt");
    m_statusLabel->setScale(.55f);
    m_statusLabel->setPosition({win.width / 2.f, 57.f});
    addChild(m_statusLabel);

    m_actionMenu = CCMenu::create();
    m_actionMenu->setPosition({0, 0});
    addChild(m_actionMenu, 5);

    auto findBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("MATCHMAKING", 165, true, "bigFont.fnt", "GJ_button_01.png", 30.f, .64f),
        this,
        menu_selector(VersusLayer::onFindMatch)
    );
    findBtn->setPosition({win.width / 2.f, win.height / 2.f + 18.f});
    m_actionMenu->addChild(findBtn);

    m_playButton = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("PLAY MATCH", 145, true, "bigFont.fnt", "GJ_button_03.png", 30.f, .62f),
        this,
        menu_selector(VersusLayer::onPlayMatch)
    );
    m_playButton->setPosition({win.width / 2.f, win.height / 2.f - 25.f});
    m_playButton->setVisible(false);
    m_actionMenu->addChild(m_playButton);

    auto jukeboxBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("JUKEBOX", 110, true, "bigFont.fnt", "GJ_button_02.png", 30.f, .62f),
        this,
        menu_selector(VersusLayer::onJukebox)
    );
    jukeboxBtn->setPosition({win.width / 2.f, win.height / 2.f - 70.f});
    m_actionMenu->addChild(jukeboxBtn);

    m_updateButton = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("CHECK UPDATE", 125, true, "bigFont.fnt", "GJ_button_05.png", 30.f, .48f),
        this,
        menu_selector(VersusLayer::onUpdate)
    );
    m_updateButton->setPosition({win.width - 72.f, 55.f});
    m_updateButton->setVisible(true);
    m_actionMenu->addChild(m_updateButton);

    m_restartButton = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("RESTART", 95, true, "bigFont.fnt", "GJ_button_05.png", 30.f, .52f),
        this,
        menu_selector(VersusLayer::onRestart)
    );
    m_restartButton->setPosition({win.width - 72.f, 29.f});
    m_restartButton->setVisible(false);
    m_actionMenu->addChild(m_restartButton);

    auto backBtn = CCMenuItemSpriteExtra::create(
        CCSprite::createWithSpriteFrameName("GJ_arrow_01_001.png"),
        this,
        menu_selector(VersusLayer::onBack)
    );
    backBtn->setPosition({25.f, win.height - 25.f});
    m_actionMenu->addChild(backBtn);

    refreshProfile();
    refreshMatchButton();
    checkInternet();
    if (Mod::get()->getSettingValue<bool>("auto-update-check")) {
        checkDriveUpdate(false);
    }
    versus::MatchState::get().checkPendingHumanResult();
    setKeypadEnabled(true);
    return true;
}

void VersusLayer::refreshProfile() {
    auto& profile = versus::Profile::get();
    if (!profile.placed()) {
        m_rankLabel->setString(fmt::format("PLACEMENT {}/10", profile.placementCount()).c_str());
        m_tierLabel->setString("ANALYZING SKILL");
    } else {
        auto info = versus::RankSystem::infoFor(profile.rating());
        m_rankLabel->setString(info.displayRating.c_str());
        m_tierLabel->setString(info.label.c_str());
    }
    rebuildRankFace();
}

void VersusLayer::rebuildRankFace() {
    if (m_rankFace) {
        m_rankFace->removeFromParent();
        m_rankFace = nullptr;
    }

    auto& profile = versus::Profile::get();
    auto info = versus::RankSystem::infoFor(profile.rating());
    auto face = GJDifficultySprite::create(
        versus::RankSystem::gdDifficultyIcon(info.tier),
        GJDifficultyName::Short
    );
    if (!face) return;

    auto win = CCDirector::sharedDirector()->getWinSize();
    face->setPosition({win.width / 2.f, win.height - 158.f});
    face->setScale(.85f);
    addChild(face, 2);
    m_rankFace = face;
}

void VersusLayer::refreshMatchButton() {
    bool ready = versus::MatchState::get().active();
    if (m_playButton) m_playButton->setVisible(ready);
}

void VersusLayer::showOfflineMessage() {
    FLAlertLayer::create(
        "Versus",
        "I can't connect to the internet. Please double-check your internet access.",
        "OK"
    )->show();
}

void VersusLayer::checkInternet() {
    auto url = Mod::get()->getSettingValue<std::string>("internet-check-url");
    if (url.empty()) return;

    web::WebRequest req;
    req.timeout(std::chrono::seconds(6));
    m_internetTask.spawn(req.get(url, Mod::get()), [this](web::WebResponse response) {
        if (!response.ok()) {
            m_statusLabel->setString("OFFLINE - BOT MODE READY");
        } else if (!versus::MatchState::get().active()) {
            m_statusLabel->setString("ONLINE");
        }
    });
}

void VersusLayer::checkDriveUpdate(bool manual) {
    auto url = Mod::get()->getSettingValue<std::string>("update-api-url");
    if (url.empty()) {
        url = "https://script.google.com/macros/s/AKfycbzwR4Nm76NM-54si1RgVH7K_rWYMAdJ1wa1rBqx6wyAw5GclV90JPmx-CBjMRXNuCBrOQ/exec";
    }

    if (m_statusLabel) m_statusLabel->setString("CHECKING UPDATE...");
    web::WebRequest req;
    req.timeout(std::chrono::seconds(10));
    m_versionTask.spawn(req.get(url, Mod::get()), [this, manual](web::WebResponse response) {
        if (!response.ok()) {
            log::warn("Versus update check failed with HTTP/status code {}", response.code());
            if (m_statusLabel) m_statusLabel->setString("UPDATE CHECK FAILED");
            if (manual) {
                FLAlertLayer::create("Update Check", "Could not reach the Versus update server.", "OK")->show();
            }
            return;
        }

        auto json = response.json();
        if (json.isErr()) {
            log::warn("Versus update check returned invalid JSON");
            if (m_statusLabel) m_statusLabel->setString("UPDATE CHECK FAILED");
            if (manual) {
                FLAlertLayer::create("Update Check", "The update server returned invalid data.", "OK")->show();
            }
            return;
        }

        auto value = json.unwrap();
        if (!value.get<bool>("ok").unwrapOr(false)) {
            auto message = value.get<std::string>("error").unwrapOr("The update server returned an error.");
            log::warn("Versus update service error: {}", message);
            if (m_statusLabel) m_statusLabel->setString("UPDATE CHECK FAILED");
            if (manual) FLAlertLayer::create("Update Check", message, "OK")->show();
            return;
        }

        auto latest = value.get<std::string>("version");
        auto download = value.get<std::string>("downloadUrl");
        if (latest.isErr() || download.isErr()) {
            if (m_statusLabel) m_statusLabel->setString("UPDATE CHECK FAILED");
            if (manual) FLAlertLayer::create("Update Check", "The update manifest is incomplete.", "OK")->show();
            return;
        }

        auto latestVersion = latest.unwrap();
        if (!newerThanCurrent(latestVersion)) {
            m_updateAvailable = false;
            if (m_statusLabel) m_statusLabel->setString("VERSUS IS UP TO DATE");
            if (manual) {
                FLAlertLayer::create(
                    "Versus Update",
                    fmt::format("You already have the latest version: <cg>{}</c>", Mod::get()->getVersion().toVString()),
                    "OK"
                )->show();
            }
            return;
        }

        m_latestVersion = latestVersion;
        m_updateDownloadUrl = download.unwrap();
        m_updateSha256 = value.get<std::string>("sha256").unwrapOr("");
        m_updateNotes = value.get<std::string>("notes").unwrapOr("");
        m_updateAvailable = true;
        if (m_statusLabel) m_statusLabel->setString("UPDATE AVAILABLE");
        showUpdatePrompt();
    });
}

void VersusLayer::showUpdatePrompt() {
    if (!m_updateAvailable || m_updateInstalling || m_updateDownloadUrl.empty()) return;

    auto current = Mod::get()->getVersion().toVString();
    std::string body = fmt::format(
        "A new Versus update is available.\n\nCurrent: <cy>{}</c>\nLatest: <cg>{}</c>",
        current,
        m_latestVersion
    );
    if (!m_updateNotes.empty()) {
        body += fmt::format("\n\n{}", m_updateNotes);
    }

    m_alertAction = AlertAction::ConfirmUpdate;
    FLAlertLayer::create(
        this,
        "Update Available!",
        body,
        "Later",
        "Update",
        380.f
    )->show();
}

void VersusLayer::showUpdateError(std::string const& message) {
    m_updateInstalling = false;
    if (m_statusLabel) m_statusLabel->setString("UPDATE FAILED");
    FLAlertLayer::create(
        "Update Failed",
        message,
        "OK"
    )->show();
}

void VersusLayer::installDriveUpdate() {
    if (!m_updateAvailable || m_updateInstalling || m_updateDownloadUrl.empty()) return;

    m_updateInstalling = true;
    if (m_statusLabel) m_statusLabel->setString("DOWNLOADING UPDATE...");

    web::WebRequest req;
    req.timeout(std::chrono::seconds(30));
    m_updateDownloadTask.spawn(req.get(m_updateDownloadUrl, Mod::get()), [this](web::WebResponse response) {
        if (!response.ok()) {
            showUpdateError(fmt::format("Could not download the update (code {}).", response.code()));
            return;
        }

        auto data = response.data();
        if (data.empty()) {
            showUpdateError("The downloaded update file was empty.");
            return;
        }

        if (!m_updateSha256.empty()) {
            auto actualHash = geode::sha256(data).toString();
            if (actualHash != m_updateSha256) {
                log::error("Versus updater SHA256 mismatch: {} != {}", actualHash, m_updateSha256);
                showUpdateError("The downloaded update failed its security check (SHA-256 mismatch).");
                return;
            }
        }

        auto packagePath = Mod::get()->getPackagePath();
        if (packagePath.empty()) {
            showUpdateError("Versus could not locate its installed .geode package.");
            return;
        }

        auto tempPath = packagePath;
        tempPath += ".download";
        auto backupPath = packagePath;
        backupPath += ".backup";

        std::error_code ec;
        std::filesystem::remove(tempPath, ec);
        ec.clear();
        std::filesystem::remove(backupPath, ec);

        auto write = geode::utils::file::writeBinary(tempPath, data);
        if (write.isErr()) {
            showUpdateError(fmt::format("Could not save the downloaded update: {}", write.unwrapErr()));
            return;
        }

        auto metadata = ModMetadata::createFromGeodeFile(tempPath);
        if (metadata.hasErrors()) {
            std::filesystem::remove(tempPath, ec);
            showUpdateError("The downloaded file is not a valid Geode mod package.");
            return;
        }
        if (metadata.getID() != "k2qr.versus") {
            std::filesystem::remove(tempPath, ec);
            showUpdateError("The downloaded package is not the Versus mod.");
            return;
        }
        if (!m_latestVersion.empty() && metadata.getVersion().toVString() != m_latestVersion) {
            std::filesystem::remove(tempPath, ec);
            showUpdateError(fmt::format(
                "The downloaded package version ({}) does not match the update service ({}).",
                metadata.getVersion().toVString(),
                m_latestVersion
            ));
            return;
        }

        versus::Profile::get().save();

        ec.clear();
        std::filesystem::rename(packagePath, backupPath, ec);
        if (ec) {
            std::filesystem::remove(tempPath, ec);
            showUpdateError("Could not prepare the existing Versus package for replacement.");
            return;
        }

        ec.clear();
        std::filesystem::rename(tempPath, packagePath, ec);
        if (ec) {
            std::error_code rollbackError;
            std::filesystem::rename(backupPath, packagePath, rollbackError);
            std::filesystem::remove(tempPath, rollbackError);
            showUpdateError("Could not install the new Versus package. The previous version was restored.");
            return;
        }

        std::filesystem::remove(backupPath, ec);
        m_updateInstalling = false;
        m_updateAvailable = false;
        if (m_updateButton) m_updateButton->setVisible(false);
        if (m_restartButton) m_restartButton->setVisible(true);
        if (m_statusLabel) m_statusLabel->setString("UPDATE READY - RESTART REQUIRED");
        showUpdateComplete();
    });
}

void VersusLayer::showUpdateComplete() {
    m_alertAction = AlertAction::RestartAfterUpdate;
    FLAlertLayer::create(
        this,
        "Update Complete!",
        "Versus has been successfully updated.\nPlease restart Geometry Dash to apply the update.",
        "Later",
        "Restart",
        380.f
    )->show();
}

void VersusLayer::showMatchReady() {
    auto const& match = versus::MatchState::get().info();
    auto kind = match.bot ? "BOT" : "PLAYER";
    m_statusLabel->setString(match.bot ? "BOT MATCH READY" : "PLAYER MATCH READY");
    refreshMatchButton();

    FLAlertLayer::create(
        "MATCH FOUND",
        fmt::format(
            "Opponent: <cg>{}</c> ({})\nRating: <cy>{}</c>\nDifficulty: <co>{}</c>\nLevel ID: <cp>{}</c>\n\nPress PLAY MATCH to start the one-run battle.",
            match.opponentName,
            kind,
            match.opponentRating,
            versus::RankSystem::difficultyName(match.difficulty),
            match.levelId
        ),
        "OK"
    )->show();
}

void VersusLayer::startBotFallback(std::string const& reason) {
    versus::MatchState::get().startLocalBot(versus::Profile::get().rating());
    m_statusLabel->setString("NO PLAYER FOUND - BOT JOINED");
    refreshMatchButton();
    auto const& match = versus::MatchState::get().info();
    FLAlertLayer::create(
        "BOT MATCH",
        fmt::format(
            "{}\n\nNo human opponent was available, so <cg>{}</c> joined instead.\nDifficulty: <cy>{}</c>\nLevel ID: <cp>{}</c>",
            reason,
            match.opponentName,
            versus::RankSystem::difficultyName(match.difficulty),
            match.levelId
        ),
        "OK"
    )->show();
}

void VersusLayer::onBack(CCObject*) {
    CCDirector::sharedDirector()->popScene();
}

void VersusLayer::onFindMatch(CCObject*) {
    if (versus::MatchState::get().active()) {
        showMatchReady();
        return;
    }

    auto base = Mod::get()->getSettingValue<std::string>("server-url");
    if (base.empty()) {
        base = "https://script.google.com/macros/s/AKfycbyAEBRk-Lsv4a81JWbtOjkDOa4XD6ns3JemrqEDu7xw-tR2DRS7qn_RaoTAuzL_QFVx/exec";
    }
    while (!base.empty() && base.back() == '/') base.pop_back();

    auto& profile = versus::Profile::get();
    auto clientId = getClientId();
    auto shortId = clientId.size() > 6 ? clientId.substr(clientId.size() - 6) : clientId;

    matjson::Value body;
    body["action"] = "findMatch";
    body["clientId"] = clientId;
    body["rating"] = profile.rating();
    body["placed"] = profile.placed();
    body["playerName"] = fmt::format("PLAYER-{}", shortId);
    body["version"] = Mod::get()->getVersion().toVString();

    web::WebRequest req;
    req.timeout(std::chrono::seconds(13));
    req.bodyJSON(body);
    m_statusLabel->setString("LIVE MATCHMAKING...");
    m_matchTask.spawn(req.post(base, Mod::get()), [this](web::WebResponse response) {
        if (!response.ok()) {
            startBotFallback("The Versus server could not be reached.");
            return;
        }

        auto json = response.json();
        if (json.isErr()) {
            startBotFallback("The matchmaking response was invalid.");
            return;
        }

        auto value = json.unwrap();
        if (!value.get<bool>("ok").unwrapOr(false)) {
            startBotFallback(value.get<std::string>("error").unwrapOr("The Versus server rejected matchmaking."));
            return;
        }

        bool bot = value.get<std::string>("opponentType").unwrapOr("bot") != "human";
        int levelId = value.get<int>("levelId").unwrapOr(6508283);
        int opponentRating = value.get<int>("opponentRating").unwrapOr(versus::Profile::get().rating());
        auto difficultyName = value.get<std::string>("difficulty").unwrapOr("Hard");
        auto opponentName = value.get<std::string>("opponentName").unwrapOr(bot ? "BOT" : "PLAYER");
        auto roomId = value.get<std::string>("roomId").unwrapOr("");
        auto ticket = value.get<std::string>("ticket").unwrapOr("");
        bool botCompleted = value.get<bool>("botCompleted").unwrapOr(false);
        float botProgress = static_cast<float>(value.get<double>("botProgress").unwrapOr(0.0));
        int botDeaths = value.get<int>("botDeaths").unwrapOr(0);

        versus::MatchState::get().startFromServer(
            bot,
            levelId,
            opponentRating,
            parseDifficulty(difficultyName),
            opponentName,
            roomId,
            ticket,
            botCompleted,
            botProgress,
            botDeaths
        );
        showMatchReady();
    });
}

void VersusLayer::onPlayMatch(CCObject*) {
    auto& state = versus::MatchState::get();
    if (!state.active()) return;

    int levelId = state.levelId();
    auto searchObject = GJSearchObject::create(
        SearchType::Type19,
        fmt::format("{}&gameVersion=22", levelId)
    );
    auto scene = LevelBrowserLayer::scene(searchObject);
    CCDirector::sharedDirector()->pushScene(CCTransitionFade::create(.35f, scene));
}

void VersusLayer::onJukebox(CCObject*) {
    auto loader = Loader::get();
    bool installed = loader->isModInstalled("fleym.nongd");
    bool loaded = loader->isModLoaded("fleym.nongd");

    if (loaded) {
        FLAlertLayer::create(
            "Jukebox",
            "Jukebox was detected and is loaded. It is ready to use with Versus levels.",
            "OK"
        )->show();
        return;
    }

    if (installed) {
        FLAlertLayer::create(
            "Jukebox",
            "Jukebox is installed, but it is not currently loaded. Enable it in Geode and restart Geometry Dash.",
            "OK"
        )->show();
        return;
    }

    geode::openInfoPopup("fleym.nongd");
    FLAlertLayer::create(
        "Jukebox Required",
        "Versus could not detect Jukebox. Install fleym.nongd v3.8.0 or newer, then restart Geometry Dash.",
        "OK"
    )->show();
}

void VersusLayer::onUpdate(CCObject*) {
    if (m_updateAvailable) showUpdatePrompt();
    else checkDriveUpdate(true);
}

void VersusLayer::onRestart(CCObject*) {
    versus::Profile::get().save();
    geode::utils::game::restart(true);
}

void VersusLayer::FLAlert_Clicked(FLAlertLayer*, bool btn2) {
    auto action = m_alertAction;
    m_alertAction = AlertAction::None;
    if (!btn2) return;

    if (action == AlertAction::ConfirmUpdate) {
        installDriveUpdate();
    } else if (action == AlertAction::RestartAfterUpdate) {
        versus::Profile::get().save();
        geode::utils::game::restart(true);
    }
}

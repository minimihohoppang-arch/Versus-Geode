#pragma once
#include <Geode/Geode.hpp>
#include <Geode/utils/web.hpp>

class VersusLayer : public cocos2d::CCLayer, public FLAlertLayerProtocol {
protected:
    enum class AlertAction {
        None,
        ConfirmUpdate,
        RestartAfterUpdate
    };

    geode::async::TaskHolder<geode::utils::web::WebResponse> m_internetTask;
    geode::async::TaskHolder<geode::utils::web::WebResponse> m_versionTask;
    geode::async::TaskHolder<geode::utils::web::WebResponse> m_updateDownloadTask;
    geode::async::TaskHolder<geode::utils::web::WebResponse> m_matchTask;
    cocos2d::CCMenu* m_actionMenu = nullptr;
    cocos2d::CCLabelBMFont* m_rankLabel = nullptr;
    cocos2d::CCLabelBMFont* m_tierLabel = nullptr;
    cocos2d::CCLabelBMFont* m_statusLabel = nullptr;
    cocos2d::CCNode* m_rankFace = nullptr;
    CCMenuItemSpriteExtra* m_playButton = nullptr;
    CCMenuItemSpriteExtra* m_updateButton = nullptr;
    CCMenuItemSpriteExtra* m_restartButton = nullptr;
    bool m_updateAvailable = false;
    bool m_updateInstalling = false;
    std::string m_latestVersion;
    std::string m_updateDownloadUrl;
    std::string m_updateSha256;
    std::string m_updateNotes;
    AlertAction m_alertAction = AlertAction::None;

    bool init() override;
    void refreshProfile();
    void rebuildRankFace();
    void refreshMatchButton();
    void checkInternet();
    void checkDriveUpdate(bool manual);
    void showOfflineMessage();
    void showMatchReady();
    void startBotFallback(std::string const& reason);
    void showUpdatePrompt();
    void installDriveUpdate();
    void showUpdateError(std::string const& message);
    void showUpdateComplete();

    void onBack(cocos2d::CCObject*);
    void onFindMatch(cocos2d::CCObject*);
    void onPlayMatch(cocos2d::CCObject*);
    void onJukebox(cocos2d::CCObject*);
    void onUpdate(cocos2d::CCObject*);
    void onRestart(cocos2d::CCObject*);
    void FLAlert_Clicked(FLAlertLayer* layer, bool btn2) override;

public:
    static VersusLayer* create();
    static cocos2d::CCScene* scene();
};

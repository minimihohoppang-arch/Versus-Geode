# Build status

This project is configured for Geode v5.10.1 and Geometry Dash 2.2081.
The included GitHub Actions workflow builds and combines Windows, Android32,
and Android64 targets into a single .geode package.

A runnable .geode package must contain platform binaries produced by the Geode
SDK toolchain; renaming or zipping the sources as .geode is not sufficient.

# Versus v0.1.0 — Geode prototype

Target: Geometry Dash 2.2081 / Geode 5.10.1 / Windows + Android.

## Included now

- Versus button on the Geometry Dash main menu.
- 10-game placement tracking.
- Local deterministic skill analysis (no paid AI required).
- Rank display from R1 to R2999, then M1 to M10000.
- Rank difficulty faces.
- Rank-aware random difficulty roulette.
- Auto and None are excluded from the roulette.
- Per-result rating gain/loss based on opponent strength and performance.
- Autosave after placement/ranked changes and before restart.
- Exact offline message requested by the design.
- Required dependency on Jukebox (`fleym.nongd >= v3.8.0`), so Geode installs it with Versus from the Index.
- Jukebox button opens its Geode page. Jukebox no longer exposes a public cross-mod API, so the stable user flow is: open a level -> tap the song name.
- Update-available button driven by `/v1/version` on the optional Versus backend.
- Restart button using Geode's cross-platform restart utility.
- Optional backend skeleton for matchmaking and GPT-assisted analysis.
- GPT model is configured on the server, never embedded in the mod. Default: `gpt-6-astra`.
- GitHub Actions workflow builds Windows, Android32 and Android64, then combines them.

## Rank mapping

The original design had two gaps and one overlap. This prototype resolves them continuously so no rating has an undefined rank:

- R1–R999: Auto
- R1000–R1099: Easy
- R1100–R1204: Normal
- R1205–R1310: Hard
- R1311–R1499: Harder
- R1500–R1699: Insane
- R1700–R1899: Easy Demon
- R1900–R2099: Medium Demon
- R2100–R2349: Hard Demon
- R2350–R2699: Insane Demon
- R2700–R2999: Extreme Demon
- internal 3000 becomes M1; max is M10000.

## Important current limitation

This is the first working source prototype, not yet a finished public online service. The mod can locally perform placement/rank/roulette/autosave and UI behavior. True online head-to-head play requires a deployed Versus backend plus the remaining room/progress synchronization and Geometry Dash level-opening integration.

The supplied backend already provides health/version, queue pairing, difficulty selection and optional GPT analysis, so it is the base for the next step.

## Building locally

Install Geode CLI/SDK, then:

```bash
geode build
geode build -p android64
```

For easiest cross-platform building, push this folder to GitHub. The included workflow produces the combined `.geode` artifact automatically.

## Server

```bash
cd server
OPENAI_API_KEY=... node index.mjs
```

The OpenAI key is optional. Without it, deterministic local rank analysis still works.

Set `Versus Server URL` in the mod's Geode settings after deploying the backend.

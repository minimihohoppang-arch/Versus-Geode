# Versus

A competitive ranked mode prototype for Geometry Dash.

Placement, rank-aware roulette, autosave, Jukebox dependency, internet checks, update/restart UI and an optional online/AI backend are included in the v0.1 foundation.

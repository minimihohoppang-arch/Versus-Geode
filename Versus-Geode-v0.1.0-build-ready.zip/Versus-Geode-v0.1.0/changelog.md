# v0.1.0

- Initial Versus foundation.
- Added 10-match placement and rank system.
- Added R -> M rank display.
- Added rank-aware roulette excluding Auto and None levels.
- Added autosave.
- Added Jukebox required dependency and integration entry.
- Added internet error popup.
- Added update/restart UI.
- Added optional matchmaking / GPT backend starter.

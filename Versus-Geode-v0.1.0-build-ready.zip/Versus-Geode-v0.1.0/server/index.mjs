import http from "node:http";
import crypto from "node:crypto";

const PORT = Number(process.env.PORT || 8787);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-6-astra";
const LATEST_VERSION = process.env.LATEST_VERSION || "v0.1.0";

const waiting = [];
const tickets = new Map();

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(body),
    "access-control-allow-origin": "*"
  });
  res.end(body);
}

async function readJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const text = Buffer.concat(chunks).toString("utf8");
  return text ? JSON.parse(text) : {};
}

function difficultyForRating(rating) {
  if (rating < 1000) return "Normal";
  if (rating < 1100) return "Easy";
  if (rating < 1205) return "Normal";
  if (rating < 1311) return "Hard";
  if (rating < 1500) return "Harder";
  if (rating < 1700) return "Insane";
  if (rating < 1900) return "Easy Demon";
  if (rating < 2100) return "Medium Demon";
  if (rating < 2350) return "Hard Demon";
  if (rating < 2700) return "Insane Demon";
  return "Extreme Demon";
}

function joinQueue(rating) {
  const ticket = crypto.randomUUID();
  const entry = { ticket, rating, created: Date.now(), match: null };
  tickets.set(ticket, entry);

  let opponentIndex = waiting.findIndex(x => Math.abs(x.rating - rating) <= 250);
  if (opponentIndex >= 0) {
    const opponent = waiting.splice(opponentIndex, 1)[0];
    const avg = Math.round((opponent.rating + rating) / 2);
    const roomId = crypto.randomUUID();
    const difficulty = difficultyForRating(avg); // Auto/None are intentionally impossible.
    const match = { roomId, difficulty };
    entry.match = match;
    opponent.match = match;
    return entry;
  }

  waiting.push(entry);
  return entry;
}

async function gptAnalyze(payload) {
  if (!OPENAI_API_KEY) return { enabled: false, reason: "OPENAI_API_KEY is not configured" };

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      reasoning: { effort: "low" },
      input: [
        {
          role: "system",
          content: [{ type: "input_text", text: "You are a Geometry Dash Versus skill analyst. Return short, practical skill observations. Do not override the deterministic rating algorithm." }]
        },
        {
          role: "user",
          content: [{ type: "input_text", text: JSON.stringify(payload) }]
        }
      ]
    })
  });

  if (!response.ok) throw new Error(`OpenAI ${response.status}`);
  const data = await response.json();
  return { enabled: true, model: OPENAI_MODEL, output: data.output_text || "" };
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (req.method === "OPTIONS") {
      res.writeHead(204, {
        "access-control-allow-origin": "*",
        "access-control-allow-methods": "GET,POST,OPTIONS",
        "access-control-allow-headers": "content-type"
      });
      return res.end();
    }

    if (req.method === "GET" && url.pathname === "/health") {
      return json(res, 200, { ok: true });
    }

    if (req.method === "GET" && url.pathname === "/v1/version") {
      return json(res, 200, { latestVersion: LATEST_VERSION });
    }

    if (req.method === "POST" && url.pathname === "/v1/match/join") {
      const body = await readJson(req);
      const rating = Math.max(1, Math.min(12999, Number(body.rating || 1000)));
      const entry = joinQueue(rating);
      return json(res, 200, {
        ticket: entry.ticket,
        state: entry.match ? "matched" : "queued",
        roomId: entry.match?.roomId || null,
        difficulty: entry.match?.difficulty || difficultyForRating(rating)
      });
    }

    if (req.method === "GET" && url.pathname === "/v1/match/status") {
      const ticket = url.searchParams.get("ticket") || "";
      const entry = tickets.get(ticket);
      if (!entry) return json(res, 404, { error: "unknown ticket" });
      return json(res, 200, {
        state: entry.match ? "matched" : "queued",
        roomId: entry.match?.roomId || null,
        difficulty: entry.match?.difficulty || difficultyForRating(entry.rating)
      });
    }

    if (req.method === "POST" && url.pathname === "/v1/ai/analyze") {
      const body = await readJson(req);
      return json(res, 200, await gptAnalyze(body));
    }

    return json(res, 404, { error: "not found" });
  } catch (error) {
    return json(res, 500, { error: String(error?.message || error) });
  }
});

server.listen(PORT, () => {
  console.log(`Versus backend listening on :${PORT}`);
  console.log(`OpenAI model: ${OPENAI_MODEL} (${OPENAI_API_KEY ? "enabled" : "disabled"})`);
});

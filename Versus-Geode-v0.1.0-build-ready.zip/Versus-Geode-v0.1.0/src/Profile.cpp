#include "Profile.hpp"
#include <Geode/Geode.hpp>

using namespace geode::prelude;

namespace versus {

Profile& Profile::get() {
    static Profile instance;
    if (!instance.m_loaded) instance.load();
    return instance;
}

void Profile::load() {
    auto mod = Mod::get();
    m_placed = mod->getSavedValue<bool>("placed", false);
    m_rating = mod->getSavedValue<int>("rating", 1000);

    auto wins = mod->getSavedValue<std::vector<int>>("p-wins", {});
    auto clears = mod->getSavedValue<std::vector<int>>("p-clears", {});
    auto progress = mod->getSavedValue<std::vector<float>>("p-progress", {});
    auto deaths = mod->getSavedValue<std::vector<int>>("p-deaths", {});
    auto opponents = mod->getSavedValue<std::vector<int>>("p-opponents", {});
    auto difficulties = mod->getSavedValue<std::vector<int>>("p-difficulties", {});

    size_t n = std::min({wins.size(), clears.size(), progress.size(), deaths.size(), opponents.size(), difficulties.size()});
    m_placement.clear();
    for (size_t i = 0; i < n && i < RankSystem::kPlacementMatches; ++i) {
        MatchRecord r;
        r.won = wins[i] != 0;
        r.completed = clears[i] != 0;
        r.progress = progress[i];
        r.deaths = deaths[i];
        r.opponentRating = opponents[i];
        r.difficulty = static_cast<PlayDifficulty>(std::clamp(difficulties[i], 1, 10));
        m_placement.push_back(r);
    }
    m_loaded = true;
}

void Profile::save() {
    auto mod = Mod::get();
    std::vector<int> wins, clears, deaths, opponents, difficulties;
    std::vector<float> progress;
    for (auto const& r : m_placement) {
        wins.push_back(r.won ? 1 : 0);
        clears.push_back(r.completed ? 1 : 0);
        progress.push_back(r.progress);
        deaths.push_back(r.deaths);
        opponents.push_back(r.opponentRating);
        difficulties.push_back(static_cast<int>(r.difficulty));
    }

    mod->setSavedValue("placed", m_placed);
    mod->setSavedValue("rating", m_rating);
    mod->setSavedValue("p-wins", wins);
    mod->setSavedValue("p-clears", clears);
    mod->setSavedValue("p-progress", progress);
    mod->setSavedValue("p-deaths", deaths);
    mod->setSavedValue("p-opponents", opponents);
    mod->setSavedValue("p-difficulties", difficulties);

    if (auto result = mod->saveData(); result.isErr()) {
        log::warn("Versus autosave failed: {}", result.unwrapErr());
    }
}

void Profile::resetPlacement() {
    m_placed = false;
    m_rating = 1000;
    m_placement.clear();
    save();
}

void Profile::addPlacement(MatchRecord const& record) {
    if (m_placed) return;
    if (m_placement.size() < RankSystem::kPlacementMatches) m_placement.push_back(record);
    if (m_placement.size() >= RankSystem::kPlacementMatches) {
        m_rating = RankSystem::placementRating(m_placement);
        m_placed = true;
    }
    save();
}

void Profile::applyRankedResult(MatchRecord const& record) {
    if (!m_placed) {
        addPlacement(record);
        return;
    }
    m_rating = std::clamp(
        m_rating + RankSystem::ratingDelta(m_rating, record),
        1,
        RankSystem::kAbsoluteMax
    );
    save();
}

} // namespace versus

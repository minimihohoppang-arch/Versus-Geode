#pragma once
#include "RankSystem.hpp"
#include <vector>

namespace versus {

class Profile {
public:
    static Profile& get();

    void load();
    void save();
    void resetPlacement();
    void addPlacement(MatchRecord const& record);
    void applyRankedResult(MatchRecord const& record);

    bool placed() const { return m_placed; }
    int rating() const { return m_rating; }
    int placementCount() const { return static_cast<int>(m_placement.size()); }
    std::vector<MatchRecord> const& placement() const { return m_placement; }

private:
    bool m_loaded = false;
    bool m_placed = false;
    int m_rating = 1000;
    std::vector<MatchRecord> m_placement;
};

} // namespace versus

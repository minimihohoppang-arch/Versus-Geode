#include "RankSystem.hpp"
#include <Geode/binding/GJGameLevel.hpp>
#include <algorithm>
#include <cmath>
#include <random>

using namespace geode::prelude;

namespace versus {

static int clampRating(int value) {
    return std::clamp(value, 1, RankSystem::kAbsoluteMax);
}

RankInfo RankSystem::infoFor(int value) {
    int r = clampRating(value);
    RankInfo out;
    out.internalRating = r;

    if (r >= kMBaseInternal) {
        int m = std::clamp(r - kMBaseInternal + 1, 1, kMMax);
        out.tier = Tier::Master;
        out.label = "MASTER";
        out.displayRating = fmt::format("M{}", m);
        return out;
    }

    out.displayRating = fmt::format("R{}", r);
    if (r <= 999)       { out.tier = Tier::AutoRank;     out.label = "AUTO"; }
    else if (r <= 1099) { out.tier = Tier::Easy;         out.label = "EASY"; }
    else if (r <= 1204) { out.tier = Tier::Normal;       out.label = "NORMAL"; }
    else if (r <= 1310) { out.tier = Tier::Hard;         out.label = "HARD"; }
    else if (r <= 1499) { out.tier = Tier::Harder;       out.label = "HARDER"; }
    else if (r <= 1699) { out.tier = Tier::Insane;       out.label = "INSANE"; }
    else if (r <= 1899) { out.tier = Tier::EasyDemon;    out.label = "EASY DEMON"; }
    else if (r <= 2099) { out.tier = Tier::MediumDemon;  out.label = "MEDIUM DEMON"; }
    else if (r <= 2349) { out.tier = Tier::HardDemon;    out.label = "HARD DEMON"; }
    else if (r <= 2699) { out.tier = Tier::InsaneDemon;  out.label = "INSANE DEMON"; }
    else                { out.tier = Tier::ExtremeDemon; out.label = "EXTREME DEMON"; }
    return out;
}

std::string RankSystem::difficultyName(PlayDifficulty d) {
    switch (d) {
        case PlayDifficulty::Easy: return "Easy";
        case PlayDifficulty::Normal: return "Normal";
        case PlayDifficulty::Hard: return "Hard";
        case PlayDifficulty::Harder: return "Harder";
        case PlayDifficulty::Insane: return "Insane";
        case PlayDifficulty::EasyDemon: return "Easy Demon";
        case PlayDifficulty::MediumDemon: return "Medium Demon";
        case PlayDifficulty::HardDemon: return "Hard Demon";
        case PlayDifficulty::InsaneDemon: return "Insane Demon";
        case PlayDifficulty::ExtremeDemon: return "Extreme Demon";
    }
    return "Hard";
}

int RankSystem::placementRating(std::vector<MatchRecord> const& records) {
    if (records.empty()) return 1000;

    double sum = 0.0;
    double weightSum = 0.0;
    for (size_t i = 0; i < records.size(); ++i) {
        auto const& m = records[i];
        double difficulty = (static_cast<int>(m.difficulty) - 1) / 9.0; // Auto/None can never enter here.
        double progress = std::clamp(m.progress / 100.0f, 0.f, 1.f);
        double deathPenalty = std::min(m.deaths, 25) / 25.0 * 0.06;
        double performance =
            progress * 0.40 +
            (m.completed ? 0.20 : 0.0) +
            (m.won ? 0.20 : 0.0) +
            difficulty * 0.20 -
            deathPenalty;

        double recency = 1.0 + static_cast<double>(i) * 0.025;
        sum += std::clamp(performance, 0.0, 1.0) * recency;
        weightSum += recency;
    }

    double skill = weightSum > 0 ? sum / weightSum : 0.0;
    // Keeps ordinary placements in R, while exceptionally strong 10-game placements can approach Extreme Demon.
    int rating = static_cast<int>(std::lround(650.0 + skill * 2350.0));
    return std::clamp(rating, 1, kRMax);
}

int RankSystem::ratingDelta(int myRating, MatchRecord const& result) {
    int opponent = std::clamp(result.opponentRating, 1, kAbsoluteMax);
    double expected = 1.0 / (1.0 + std::pow(10.0, (opponent - myRating) / 400.0));
    double actual = result.won ? 1.0 : 0.0;

    double difficultyBoost = 0.90 + static_cast<int>(result.difficulty) * 0.025;
    double progressFactor = 0.80 + std::clamp(result.progress / 100.0f, 0.f, 1.f) * 0.20;
    int k = myRating < 1700 ? 36 : (myRating < 2700 ? 30 : 24);

    int delta = static_cast<int>(std::lround(k * (actual - expected) * difficultyBoost * progressFactor));
    if (result.won && delta < 4) delta = 4;
    if (!result.won && delta > -4) delta = -4;
    return std::clamp(delta, -60, 60);
}

PlayDifficulty RankSystem::rouletteDifficulty(int myRating, int opponentRating) {
    int basis = opponentRating > 0 ? (myRating + opponentRating) / 2 : myRating;
    int center = 1;
    if (basis < 1000) center = 2;
    else if (basis < 1100) center = 1;
    else if (basis < 1205) center = 2;
    else if (basis < 1311) center = 3;
    else if (basis < 1500) center = 4;
    else if (basis < 1700) center = 5;
    else if (basis < 1900) center = 6;
    else if (basis < 2100) center = 7;
    else if (basis < 2350) center = 8;
    else if (basis < 2700) center = 9;
    else center = 10;

    // Rank-aware randomization: mostly the expected difficulty, sometimes one step around it.
    static std::mt19937 rng(std::random_device{}());
    std::discrete_distribution<int> offsetDist({18, 64, 18});
    int offset = offsetDist(rng) - 1;
    int chosen = std::clamp(center + offset, 1, 10);

    // By construction there is no Auto and no None.
    return static_cast<PlayDifficulty>(chosen);
}

int RankSystem::gdDifficultyIcon(Tier tier) {
    switch (tier) {
        case Tier::AutoRank: return static_cast<int>(GJDifficulty::Auto);
        case Tier::Easy: return static_cast<int>(GJDifficulty::Easy);
        case Tier::Normal: return static_cast<int>(GJDifficulty::Normal);
        case Tier::Hard: return static_cast<int>(GJDifficulty::Hard);
        case Tier::Harder: return static_cast<int>(GJDifficulty::Harder);
        case Tier::Insane: return static_cast<int>(GJDifficulty::Insane);
        case Tier::EasyDemon: return GJGameLevel::demonIconForDifficulty(static_cast<DemonDifficultyType>(3));
        case Tier::MediumDemon: return GJGameLevel::demonIconForDifficulty(static_cast<DemonDifficultyType>(4));
        case Tier::HardDemon: return GJGameLevel::demonIconForDifficulty(static_cast<DemonDifficultyType>(0));
        case Tier::InsaneDemon: return GJGameLevel::demonIconForDifficulty(static_cast<DemonDifficultyType>(5));
        case Tier::ExtremeDemon: return GJGameLevel::demonIconForDifficulty(static_cast<DemonDifficultyType>(6));
        case Tier::Master: return GJGameLevel::demonIconForDifficulty(static_cast<DemonDifficultyType>(6));
    }
    return static_cast<int>(GJDifficulty::Hard);
}

} // namespace versus

#pragma once
#include <Geode/Geode.hpp>
#include <string>
#include <vector>

namespace versus {

enum class Tier {
    AutoRank,
    Easy,
    Normal,
    Hard,
    Harder,
    Insane,
    EasyDemon,
    MediumDemon,
    HardDemon,
    InsaneDemon,
    ExtremeDemon,
    Master
};

enum class PlayDifficulty {
    Easy = 1,
    Normal,
    Hard,
    Harder,
    Insane,
    EasyDemon,
    MediumDemon,
    HardDemon,
    InsaneDemon,
    ExtremeDemon
};

struct MatchRecord {
    bool won = false;
    bool completed = false;
    float progress = 0.f;      // 0..100
    int deaths = 0;
    int opponentRating = 1500;
    PlayDifficulty difficulty = PlayDifficulty::Hard;
};

struct RankInfo {
    Tier tier = Tier::AutoRank;
    std::string label;
    std::string displayRating;
    int internalRating = 1;
};

class RankSystem {
public:
    static constexpr int kPlacementMatches = 10;
    static constexpr int kRMax = 2999;
    static constexpr int kMBaseInternal = 3000;
    static constexpr int kMMax = 10000;
    static constexpr int kAbsoluteMax = kMBaseInternal + kMMax - 1;

    static RankInfo infoFor(int internalRating);
    static int placementRating(std::vector<MatchRecord> const& records);
    static int ratingDelta(int myRating, MatchRecord const& result);
    static PlayDifficulty rouletteDifficulty(int myRating, int opponentRating = -1);
    static std::string difficultyName(PlayDifficulty d);
    static int gdDifficultyIcon(Tier tier);
};

} // namespace versus

#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include "VersusLayer.hpp"
#include "Profile.hpp"

using namespace geode::prelude;

class $modify(VersusMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;

        auto menu = this->getChildByID("bottom-menu");
        if (!menu) menu = this->getChildByType<CCMenu>(0);
        if (!menu) return true;

        auto sprite = ButtonSprite::create("VERSUS", 90, true, "bigFont.fnt", "GJ_button_05.png", 30.f, .55f);
        auto button = CCMenuItemSpriteExtra::create(
            sprite,
            this,
            menu_selector(VersusMenuLayer::onVersus)
        );
        button->setID("versus-button");
        menu->addChild(button);
        menu->updateLayout();

        // Ensure save data is loaded as soon as the main menu appears.
        (void)versus::Profile::get();
        return true;
    }

    void onVersus(CCObject*) {
        auto scene = VersusLayer::scene();
        CCDirector::sharedDirector()->pushScene(CCTransitionFade::create(.25f, scene));
    }
};
